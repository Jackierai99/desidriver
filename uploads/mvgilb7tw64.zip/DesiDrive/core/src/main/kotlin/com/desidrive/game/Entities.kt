package com.desidrive.game

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.min

enum class Beh { WALK, JOG, STAND, PHONE }

/** ex = comma separated look tags, e.g. "lungi:3b5ea8,stache,towel:c9b99a" */
class NpcType(
    val name: String, shirtHex: String, pantsHex: String, skinHex: String, hatHex: String?,
    val beh: Beh, val scale: Float = 1f, val speed: Float = 1.4f, ex: String = ""
) {
    val shirt: Color = Color.valueOf(shirtHex)
    val pants: Color = Color.valueOf(pantsHex)
    val skin: Color = Color.valueOf(skinHex)
    val hat: Color? = if (hatHex != null) Color.valueOf(hatHex) else null
    val tags: Map<String, String> = ex.split(",").filter { it.isNotBlank() }.associate {
        val p = it.split(":")
        p[0] to (if (p.size > 1) p[1] else "")
    }
    fun has(t: String): Boolean = tags.containsKey(t)
    fun col(t: String, def: String): Color {
        val v = tags[t]
        return Color.valueOf(if (v == null || v.isEmpty()) def else v)
    }
}

private const val SK1 = "8d5524"
private const val SK2 = "c68642"
private const val SK3 = "e0ac69"

/** The 10 DesiDriver NPCs (from the character sheets). Index 0 = chaiwala (scripted in mission 1). */
val NPC_TYPES: List<NpcType> = listOf(
    NpcType("Chaiwala Ramesh", "8fb0d6", "3b5ea8", SK2, null, Beh.STAND, 1f, 1.4f, "lungi:3b5ea8,stache,towel:c9b99a,shoes:6b4a2b"),
    NpcType("Bike wala Rahul", "3a5a40", "35557a", SK2, null, Beh.WALK, 1f, 1.4f, "beard,shoes:222222"),
    NpcType("Traffic Police Mahesh Kumar", "f2f2f2", "ececec", SK2, "f2f2f2", Beh.STAND, 1f, 1.4f, "pcap,belt,stache,shoes:111111"),
    NpcType("Sabziwali Sunita Devi", "a8322d", "2f7d3a", SK2, null, Beh.STAND, 0.95f, 1.2f, "saree:2f7d3a,bun,hair:2a2a2a"),
    NpcType("Student Arjun Sharma", "2c3e66", "18181b", SK3, null, Beh.WALK, 1f, 1.5f, "backpack:2b2b2b,shoes:eeeeee"),
    NpcType("Auto driver Shakeel Khan", "c9bb8a", "2b3a2b", SK2, null, Beh.STAND, 1f, 1.4f, "stache,shoes:6b4a2b"),
    NpcType("Kisan Ramlal", "e7dfc9", "efefef", SK1, "d8cfb8", Beh.WALK, 1f, 1.0f, "turban,dhoti:efefef,stache,hair:777777,bag:8a6a43,towel:a89c80,staff,shoes:6b4a2b"),
    NpcType("Delivery rider Vicky", "ee7a2a", "18181b", SK2, "ee7a2a", Beh.JOG, 1f, 1.8f, "helmet,box:ee7a2a,beard,shoes:333333"),
    NpcType("Office worker Amit Verma", "b9c9e3", "2e2f33", SK2, null, Beh.WALK, 1f, 1.5f, "bag:222222,shoes:111111"),
    NpcType("Dadaji Gopal Sharma", "efe6d0", "e9e1cb", SK2, null, Beh.WALK, 0.97f, 0.9f, "vest:9c7f55,glasses,stache,hair:b5b5b5,cane,shoes:6b4a2b")
)

class Human(val type: NpcType) {
    var x = 0f; var z = 0f; var yaw = 0f
    var anim = 0f; var moving = false; var amp = 38f
    var hp = 100f; var alive = true; var isBoss = false
    // walker path
    var axisX = false; var fixed = 0f; var lo = 0f; var hi = 0f; var dir = 1f; var t = 0f

    private class Ex(val inst: ModelInstance, val lx: Float, val ly: Float, val lz: Float,
                      val sx: Float, val sy: Float, val sz: Float, val rz: Float)

    private val exs = ArrayList<Ex>()
    private val phone = type.beh == Beh.PHONE
    private val sphereHat = type.has("turban") || type.has("helmet")
    private val hairC = type.col("hair", "141414")
    private val shoeC = type.col("shoes", "1b1b1b")
    private val legL = Gfx.cyl(type.pants)
    private val legR = Gfx.cyl(type.pants)
    private val shoeL = Gfx.box(shoeC)
    private val shoeR = Gfx.box(shoeC)
    private val armL = Gfx.cyl(type.shirt)
    private val armR = Gfx.cyl(type.shirt)
    private val torso = Gfx.cyl(type.shirt)
    private val head = Gfx.sphere(type.skin)
    private val topI: ModelInstance = run {
        val h = type.hat
        if (h != null) (if (sphereHat) Gfx.sphere(h) else Gfx.cyl(h)) else Gfx.sphere(hairC)
    }
    private val phoneI: ModelInstance? = if (phone) Gfx.box(Color.BLACK) else null

    private fun ex(i: ModelInstance, lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float, rz: Float = 0f) {
        exs.add(Ex(i, lx, ly, lz, sx, sy, sz, rz))
    }

    private fun buildExtras() {
        val t = type
        val dark = Color.valueOf("151515")
        val navy = Color.valueOf("232a5c")
        if (t.has("lungi")) ex(Gfx.cyl(t.col("lungi", "3b5ea8")), 0f, 0.66f, 0f, 0.46f, 0.62f, 0.34f)
        if (t.has("dhoti")) ex(Gfx.cyl(t.col("dhoti", "efefef")), 0f, 0.62f, 0f, 0.50f, 0.70f, 0.36f)
        if (t.has("saree")) {
            val sc = t.col("saree", "2f7d3a")
            ex(Gfx.cyl(sc), 0f, 0.56f, 0f, 0.50f, 0.90f, 0.38f)
            ex(Gfx.box(sc), 0.02f, 1.22f, 0.02f, 0.09f, 0.70f, 0.30f, -28f)
        }
        if (t.has("vest")) ex(Gfx.cyl(t.col("vest", "9c7f55")), 0f, 1.17f, 0f, 0.50f, 0.50f, 0.30f)
        if (t.has("hoodie")) {
            ex(Gfx.sphere(t.shirt), 0f, 1.50f, -0.07f, 0.30f, 0.14f, 0.22f)
            ex(Gfx.box(Color.WHITE), 0f, 1.28f, -0.14f, 0.13f, 0.15f, 0.01f)
        }
        if (t.has("belt")) {
            ex(Gfx.cyl(dark), 0f, 0.96f, 0f, 0.48f, 0.07f, 0.28f)
            ex(Gfx.box(dark), 0.27f, 0.88f, 0f, 0.08f, 0.20f, 0.10f)
        }
        if (t.has("backpack")) {
            val bc = t.col("backpack", "2b2b2b")
            ex(Gfx.box(bc), 0f, 1.25f, -0.22f, 0.34f, 0.46f, 0.16f)
            ex(Gfx.box(bc), -0.12f, 1.32f, 0.14f, 0.05f, 0.50f, 0.03f)
            ex(Gfx.box(bc), 0.12f, 1.32f, 0.14f, 0.05f, 0.50f, 0.03f)
        }
        if (t.has("box")) ex(Gfx.box(t.col("box", "ee7a2a")), 0f, 1.28f, -0.33f, 0.50f, 0.50f, 0.42f)
        if (t.has("bag")) {
            val bc = t.col("bag", "2b2b2b")
            ex(Gfx.box(bc), 0.34f, 0.90f, 0f, 0.12f, 0.24f, 0.28f)
            ex(Gfx.box(bc), 0.12f, 1.20f, 0.14f, 0.04f, 0.75f, 0.03f, -30f)
        }
        if (t.has("towel")) ex(Gfx.box(t.col("towel", "c9b99a")), -0.2f, 1.42f, 0f, 0.12f, 0.42f, 0.30f, 8f)
        if (t.has("cane")) ex(Gfx.cyl(Color.valueOf("6b4a2b")), 0.36f, 0.5f, 0.12f, 0.04f, 1.0f, 0.04f)
        if (t.has("staff")) ex(Gfx.cyl(Color.valueOf("6b4a2b")), 0.38f, 0.85f, 0.12f, 0.05f, 1.7f, 0.05f)
        if (t.has("sun")) ex(Gfx.box(Color.BLACK), 0f, 1.67f, 0.125f, 0.25f, 0.06f, 0.05f)
        if (t.has("glasses")) ex(Gfx.box(Color.valueOf("2b2b2b")), 0f, 1.67f, 0.13f, 0.24f, 0.045f, 0.03f)
        if (t.has("stache")) ex(Gfx.box(hairC), 0f, 1.595f, 0.125f, 0.12f, 0.03f, 0.04f)
        if (t.has("beard")) ex(Gfx.sphere(hairC), 0f, 1.56f, 0.06f, 0.20f, 0.15f, 0.18f)
        if (t.has("bun")) ex(Gfx.sphere(hairC), 0f, 1.68f, -0.17f, 0.15f, 0.15f, 0.15f)
        if (t.has("pcap")) {
            ex(Gfx.cyl(Color.valueOf("f2f2f2")), 0f, 1.89f, 0f, 0.35f, 0.05f, 0.35f)
            ex(Gfx.cyl(navy), 0f, 1.80f, 0f, 0.31f, 0.04f, 0.31f)
            ex(Gfx.box(navy), 0f, 1.79f, 0.15f, 0.26f, 0.02f, 0.15f)
        }
        if (t.has("helmet")) ex(Gfx.box(Color.BLACK), 0f, 1.68f, 0.16f, 0.24f, 0.09f, 0.05f)
    }

    init { buildExtras() }

    val parts: List<ModelInstance> =
        listOfNotNull(legL, legR, shoeL, shoeR, armL, armR, torso, head, topI, phoneI) + exs.map { it.inst }

    private fun limb(i: ModelInstance, lx: Float, hipY: Float, swing: Float, len: Float, w: Float, d: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, hipY, 0f).rotate(Vector3.X, swing).translate(0f, -len / 2f, 0f).scale(w, len, d)
    }

    private fun foot(i: ModelInstance, lx: Float, hipY: Float, swing: Float, len: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, hipY, 0f).rotate(Vector3.X, swing).translate(0f, -len + 0.04f, 0.06f).scale(0.2f, 0.09f, 0.34f)
    }

    private fun part(i: ModelInstance, lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float, rz: Float = 0f) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, ly, lz)
        if (rz != 0f) i.transform.rotate(Vector3.Z, rz)
        i.transform.scale(sx, sy, sz)
    }

    fun layout() {
        val sw = if (moving) MathUtils.sin(anim) * amp else 0f
        val bob = if (moving) abs(MathUtils.sin(anim)) * 0.03f else 0f
        limb(legL, -0.11f, 0.85f, sw, 0.85f, 0.18f, 0.2f)
        limb(legR, 0.11f, 0.85f, -sw, 0.85f, 0.18f, 0.2f)
        foot(shoeL, -0.11f, 0.85f, sw, 0.85f)
        foot(shoeR, 0.11f, 0.85f, -sw, 0.85f)
        limb(armL, -0.3f, 1.48f, -sw * 0.8f, 0.6f, 0.14f, 0.16f)
        if (phone) limb(armR, 0.3f, 1.48f, -150f, 0.4f, 0.14f, 0.16f)
        else limb(armR, 0.3f, 1.48f, sw * 0.8f, 0.6f, 0.14f, 0.16f)
        part(torso, 0f, 1.2f + bob, 0f, 0.46f, 0.62f, 0.26f)
        part(head, 0f, 1.64f + bob, 0f, 0.27f, 0.30f, 0.27f)
        if (type.hat != null) {
            if (sphereHat) part(topI, 0f, 1.76f + bob, 0f, 0.34f, 0.24f, 0.34f)
            else part(topI, 0f, 1.84f + bob, 0f, 0.30f, 0.10f, 0.30f)
        } else if (type.has("bighair")) part(topI, 0f, 1.745f + bob, -0.02f, 0.33f, 0.33f, 0.34f)
        else part(topI, 0f, 1.70f + bob, -0.012f, 0.285f, 0.27f, 0.29f)
        phoneI?.let { part(it, 0.3f, 1.84f, 0.2f, 0.07f, 0.14f, 0.03f) }
        for (e in exs) part(e.inst, e.lx, e.ly + bob, e.lz, e.sx, e.sy, e.sz, e.rz)
    }
}

class CarSpec(
    val name: String, val body: Color, val cabin: Color,
    val len: Float, val wid: Float, val bodyH: Float, val cabinH: Float, val clearance: Float,
    val maxSpeed: Float, val accel: Float, val brake: Float, val wheelBase: Float,
    val kind: Int = 0, val wheelR: Float = 0.36f, val file: String = ""
)

/** kind: 0 sedan, 1 SUV, 2 supercar, 3 auto-rickshaw, 4 Thar-style boxy 4x4, 5 hatchback */
object CarSpecs {
    private val DK = Color.valueOf("111827")
    val THAR = CarSpec("Mahindra Thar", Color.valueOf("151515"), Color.valueOf("151515"), 4.2f, 1.86f, 0.95f, 0.78f, 0.50f, 34f, 10f, 22f, 2.6f, 4, 0.43f, "thar")
    val SWIFT = CarSpec("Maruti Swift", Color.valueOf("c8202a"), DK, 3.85f, 1.74f, 0.80f, 0.70f, 0.22f, 40f, 12f, 24f, 2.45f, 5, 0.33f, "swift")
    val FORTUNER = CarSpec("Toyota Fortuner", Color.valueOf("f1f1f1"), DK, 4.8f, 1.86f, 1.05f, 0.82f, 0.42f, 38f, 10f, 22f, 2.75f, 1, 0.42f, "fortuner")
    val HURACAN = CarSpec("Lamborghini Huracan", Color.valueOf("f3c613"), DK, 4.5f, 1.95f, 0.62f, 0.50f, 0.13f, 70f, 20f, 34f, 2.62f, 2, 0.35f, "huracan")
    val NEXON = CarSpec("Tata Nexon", Color.valueOf("1c4fb5"), DK, 4.0f, 1.82f, 0.92f, 0.72f, 0.30f, 38f, 12f, 24f, 2.5f, 1, 0.37f, "nexon")
    val AUTO = CarSpec("Auto Rickshaw", Color.valueOf("2e7d32"), Color.valueOf("1a1a1a"), 2.8f, 1.4f, 0.8f, 0.9f, 0.35f, 15f, 5f, 12f, 1.8f, 3, 0.30f, "auto")
}

class Car(val spec: CarSpec, var x: Float, var z: Float, var yaw: Float, tint: Color? = null) {
    var speed = 0f
    var steer = 0f   // radians, + = right

    private val ext: ExtCar? = Gfx.externalCar(spec)
    private val cm: CarModel? = if (ext == null) Gfx.carModel(spec, tint ?: spec.body) else null
    private val body: ModelInstance = ModelInstance(ext?.model ?: cm!!.body)

    // wheel slots: lx, lz, steers(1/0)
    private val wpos: Array<FloatArray> = run {
        val xo = spec.wid * 0.5f - 0.09f
        val hb = spec.wheelBase * 0.5f
        if (spec.kind == 3) arrayOf(floatArrayOf(0f, hb, 1f), floatArrayOf(-xo, -hb, 0f), floatArrayOf(xo, -hb, 0f))
        else arrayOf(floatArrayOf(-xo, hb, 1f), floatArrayOf(xo, hb, 1f), floatArrayOf(-xo, -hb, 0f), floatArrayOf(xo, -hb, 0f))
    }
    private val wheels: List<ModelInstance> =
        if (cm != null) List(wpos.size) { ModelInstance(cm.wheel) } else emptyList()
    val parts: List<ModelInstance> = listOf(body) + wheels

    private var spin = 0f
    private var pitch = 0f
    private var roll = 0f
    private var lastSpeed = 0f

    fun layout() {
        val dt = min(Gdx.graphics.deltaTime, 0.05f)
        val e = ext
        if (e != null) {
            body.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw + e.yaw)
                .scale(e.scale, e.scale, e.scale).translate(-e.cx, -e.minY, -e.cz)
            return
        }
        val acc = if (dt > 0f) ((speed - lastSpeed) / dt).coerceIn(-30f, 30f) else 0f
        lastSpeed = speed
        pitch += ((-acc * 0.06f).coerceIn(-3f, 3f) - pitch) * min(1f, dt * 6f)
        val sf = (abs(speed) / spec.maxSpeed).coerceIn(0f, 1f)
        roll += (-steer * sf * 9f - roll) * min(1f, dt * 6f)
        spin = (spin + speed * dt / spec.wheelR * MathUtils.radiansToDegrees) % 360f

        body.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw)
            .rotate(Vector3.Z, roll).rotate(Vector3.X, pitch)
        for (k in wheels.indices) {
            val wp = wpos[k]
            val w = wheels[k]
            w.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).translate(wp[0], spec.wheelR, wp[1])
            if (wp[2] > 0f) w.transform.rotate(Vector3.Y, -steer * MathUtils.radiansToDegrees)
            w.transform.rotate(Vector3.X, spin)
        }
    }
}
