package com.desidrive.game

import com.badlogic.gdx.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Box(val x0: Float, val z0: Float, val x1: Float, val z1: Float)
class MapRect(val x0: Float, val z0: Float, val x1: Float, val z1: Float, val c: Color)

class World {
    val roads = floatArrayOf(-160f, -80f, 0f, 80f, 160f)
    val half = 208f
    val colliders = ArrayList<Box>()
    val mapRects = ArrayList<MapRect>()
    val chunks: ArrayList<ChunkInst>
    private val sbd = StaticBuilder()
    private val rnd = java.util.Random(7)

    private fun c(hex: String) = Color.valueOf(hex)
    private val palette = listOf("ee8fa6", "f7d166", "59bfbf", "f2994a", "f2e6c7", "8db3e6", "99d9b3", "cc7359").map { c(it) }
    private val SIDEWALK = c("9a9a98")
    private val ROOF = c("6d6d6d"); private val TANK = c("1b1b1b")
    private val TRUNK = c("5a3d27"); private val GREY = c("9aa0a6"); private val WHITE = c("f5f5f5")
    private val LAMP = c("fff2c0"); private val POLE = c("5b6066"); private val ZEBRA = c("e8e8e2")
    private val greens = listOf("2e7d32", "388e3c", "43a047", "1b5e20", "558b2f").map { c(it) }

    init {
        build()
        chunks = sbd.finish()
    }

    private fun addBox(col: Color, cx: Float, y: Float, cz: Float, sx: Float, sy: Float, sz: Float, caster: Boolean = true, solid: Boolean = false) {
        sbd.box(if (caster) G.SOLID else G.FLAT, col, cx, y, cz, sx, sy, sz)
        if (solid) colliders.add(Box(cx - sx / 2f, cz - sz / 2f, cx + sx / 2f, cz + sz / 2f))
    }

    private fun addCyl(col: Color, cx: Float, y: Float, cz: Float, d: Float, h: Float, caster: Boolean = true, solid: Boolean = false) {
        sbd.cyl(if (caster) G.SOLID else G.FLAT, col, cx, y, cz, d, h, d)
        if (solid) colliders.add(Box(cx - d / 2f, cz - d / 2f, cx + d / 2f, cz + d / 2f))
    }

    private fun addSphere(col: Color, cx: Float, y: Float, cz: Float, d: Float) {
        sbd.sphere(G.SOLID, col, cx, y, cz, d, d * 0.85f, d)
    }

    private fun addCone(col: Color, cx: Float, y: Float, cz: Float, d: Float, h: Float) {
        sbd.cone(G.SOLID, col, cx, y, cz, d, h, d)
    }

    private fun building(cx: Float, cz: Float, w: Float, d: Float, h: Float, col: Color, tank: Boolean = true, billboard: Boolean = false) {
        val sh = min(4.2f, h * 0.45f)
        val shopTint = col.cpy().lerp(Color.WHITE, 0.55f)
        sbd.facade(G.SHOP, shopTint, cx, cz, w, d, 0f, sh, 6f, sh)
        sbd.facade(G.FACADE, col, cx, cz, w, d, sh, h, 4f, 3.2f)
        colliders.add(Box(cx - w / 2f, cz - d / 2f, cx + w / 2f, cz + d / 2f))
        mapRects.add(MapRect(cx - w / 2f, cz - d / 2f, cx + w / 2f, cz + d / 2f, col))
        addBox(ROOF, cx, h + 0.15f, cz, w + 0.6f, 0.3f, d + 0.6f, true, false)
        // parapet
        addBox(ROOF, cx, h + 0.6f, cz + d / 2f, w + 0.4f, 0.6f, 0.25f)
        addBox(ROOF, cx, h + 0.6f, cz - d / 2f, w + 0.4f, 0.6f, 0.25f)
        addBox(ROOF, cx + w / 2f, h + 0.6f, cz, 0.25f, 0.6f, d + 0.4f)
        addBox(ROOF, cx - w / 2f, h + 0.6f, cz, 0.25f, 0.6f, d + 0.4f)
        if (tank) {
            addCyl(TANK, cx + w * 0.25f, h + 1.7f, cz - d * 0.2f, 2.0f, 1.8f)
            for (lx in floatArrayOf(-0.7f, 0.7f)) addBox(GREY, cx + w * 0.25f + lx, h + 0.6f, cz - d * 0.2f, 0.12f, 0.6f, 0.12f)
        }
        addBox(GREY, cx - w * 0.28f, h + 0.9f, cz + d * 0.15f, 1.3f, 0.9f, 1.1f)       // AC / lift room
        if (billboard) addBox(palette[rnd.nextInt(palette.size)], cx, h + 4.0f, cz + d * 0.3f, w * 0.7f, 3f, 0.4f)
    }

    private fun tree(x: Float, z: Float) {
        val s = 0.85f + rnd.nextFloat() * 0.4f
        addCyl(TRUNK, x, 1.6f * s, z, 0.5f, 3.2f * s, true, true)
        val g = greens[rnd.nextInt(greens.size)]
        addSphere(g, x, 4.6f * s, z, 3.8f * s)
        addSphere(greens[rnd.nextInt(greens.size)], x + 0.9f * s, 5.4f * s, z + 0.3f, 2.6f * s)
    }

    private fun walk(cx: Float, cz: Float, sx: Float, sz: Float) {
        sbd.box(G.FLAT, SIDEWALK, cx, 0.1f, cz, sx, 0.2f, sz)
        val x0 = cx - sx / 2f; val x1 = cx + sx / 2f; val z0 = cz - sz / 2f; val z1 = cz + sz / 2f
        sbd.flat(G.WALK, Color.WHITE, x0, z0, x1, z1, 0.205f, x0 / 2f, z0 / 2f, x1 / 2f, z1 / 2f)
    }

    private fun lamp(x: Float, z: Float, towardsX: Float, towardsZ: Float) {
        addCyl(POLE, x, 3.2f, z, 0.16f, 6.4f, true, false)
        addBox(POLE, x + towardsX * 0.7f, 6.35f, z + towardsZ * 0.7f, if (towardsX != 0f) 1.4f else 0.1f, 0.1f, if (towardsZ != 0f) 1.4f else 0.1f, false)
        addBox(LAMP, x + towardsX * 1.3f, 6.25f, z + towardsZ * 1.3f, 0.55f, 0.12f, 0.35f, false)
    }

    private fun build() {
        // ---- ground (textured dirt/grass)
        for (ix in 0 until 8) for (iz in 0 until 8) {
            val x0 = -256f + ix * 64f; val z0 = -256f + iz * 64f
            sbd.flat(G.GROUND, Color.WHITE, x0, z0, x0 + 64f, z0 + 64f, 0f, x0 / 12f, z0 / 12f, (x0 + 64f) / 12f, (z0 + 64f) / 12f)
        }
        // ---- roads (segments between junctions, junction squares, zebra crossings)
        val bounds = ArrayList<Float>(); bounds.add(-220f); for (r in roads) bounds.add(r); bounds.add(220f)
        for (r in roads) {
            for (i in 0 until bounds.size - 1) {
                val a = if (i == 0) bounds[0] else bounds[i] + 6f
                val b = if (i == bounds.size - 2) bounds[i + 1] else bounds[i + 1] - 6f
                sbd.flat(G.ROAD, Color.WHITE, r - 6f, a, r + 6f, b, 0.03f, 0f, a / 16f, 1f, b / 16f)
                sbd.flat(G.ROAD, Color.WHITE, a, r - 6f, b, r + 6f, 0.03f, 0f, a / 16f, 1f, b / 16f, true)
            }
        }
        for (rx in roads) for (rz in roads) {
            sbd.flat(G.ASPH, Color.WHITE, rx - 6f, rz - 6f, rx + 6f, rz + 6f, 0.035f, 0f, 0f, 3f, 3f)
            for (sg in floatArrayOf(-1f, 1f)) {
                val a = 6.6f; val b = 8.4f
                val za0 = min(rz + sg * a, rz + sg * b); val za1 = max(rz + sg * a, rz + sg * b)
                val xa0 = min(rx + sg * a, rx + sg * b); val xa1 = max(rx + sg * a, rx + sg * b)
                for (k in 0 until 8) {
                    val o = -4.5f + k * 1.3f
                    sbd.flat(G.FLAT, ZEBRA, rx + o - 0.35f, za0, rx + o + 0.35f, za1, 0.045f, 0f, 0f, 1f, 1f)
                    sbd.flat(G.FLAT, ZEBRA, xa0, rz + o - 0.35f, xa1, rz + o + 0.35f, 0.045f, 0f, 0f, 1f, 1f)
                }
            }
        }
        // ---- sidewalks (broken at intersections)
        for (r in roads) for (s in floatArrayOf(-7.5f, 7.5f)) {
            for (i in 0 until bounds.size - 1) {
                val a = if (i == 0) bounds[0] else bounds[i] + 6f
                val b = if (i == bounds.size - 2) bounds[i + 1] else bounds[i + 1] - 6f
                val mid = (a + b) / 2f; val len = b - a
                walk(r + s, mid, 3f, len)
                walk(mid, r + s, len, 3f)
            }
        }
        // ---- street trees + lamps
        for (r in roads) for (side in floatArrayOf(-8.4f, 8.4f)) {
            var s = -200f
            while (s <= 200f) {
                val p = s + rnd.nextFloat() * 8f
                if (roads.none { abs(p - it) < 14f } && rnd.nextFloat() < 0.55f) tree(r + side, p)
                if (roads.none { abs(p - it) < 14f } && rnd.nextFloat() < 0.55f) tree(p, r + side)
                s += 22f
            }
        }
        for (r in roads) for (side in floatArrayOf(-7.2f, 7.2f)) {
            var s = -195f
            while (s <= 195f) {
                if (roads.none { abs(s - it) < 12f }) {
                    val tw = if (side > 0) -1f else 1f
                    lamp(r + side, s, tw, 0f)
                    lamp(s, r + side, 0f, tw)
                }
                s += 30f
            }
        }

        val reserved = setOf(
            Pair(-120f, -120f), Pair(-40f, -120f), Pair(-40f, 40f),
            Pair(120f, -40f), Pair(40f, 120f), Pair(120f, 120f), Pair(40f, -40f)
        )
        val cs = floatArrayOf(-120f, -40f, 40f, 120f)

        // ARMY BASE (-120,-120)
        building(-135f, -138f, 22f, 12f, 7f, c("6b7a3a"), false)
        addCyl(GREY, -100f, 6f, -140f, 0.2f, 12f, true, true)
        addBox(c("ff9933"), -98.3f, 11.4f, -140f, 3.2f, 0.7f, 0.05f)
        addBox(WHITE, -98.3f, 10.7f, -140f, 3.2f, 0.7f, 0.05f)
        addBox(c("138808"), -98.3f, 10.0f, -140f, 3.2f, 0.7f, 0.05f)
        addBox(c("4b5320"), -112f, 1.2f, -140f, 5f, 2.4f, 2.4f, true, true) // army truck body

        // TEMPLE (-40,-120)
        addBox(c("d9d2c3"), -40f, 0.6f, -120f, 26f, 1.2f, 26f, true, true)
        addBox(c("fff3e0"), -40f, 4.2f, -120f, 14f, 6f, 14f)
        addBox(c("ffcc80"), -40f, 9.7f, -120f, 10f, 5f, 10f)
        addBox(c("ff9800"), -40f, 14.2f, -120f, 6f, 4f, 6f)
        addCone(c("ff9800"), -40f, 19.2f, -120f, 5f, 6f)
        addSphere(c("f1c40f"), -40f, 22.6f, -120f, 1.4f)
        for (dx in floatArrayOf(-10f, 10f)) for (dz in floatArrayOf(-10f, 10f)) addCyl(WHITE, -40f + dx, 4.2f, -120f + dz, 1.2f, 6f)
        mapRects.add(MapRect(-53f, -133f, -27f, -107f, c("d9a066")))

        // CHAI TAPRI near mission 1
        addBox(c("7a4b2a"), -33f, 0.5f, -98f, 3f, 1f, 1.5f, true, true)
        addBox(c("ff7043"), -33f, 2.7f, -98f, 3.8f, 0.15f, 2.4f)
        for (dx in floatArrayOf(-1.6f, 1.6f)) for (dz in floatArrayOf(-1f, 1f)) addCyl(GREY, -33f + dx, 1.35f, -98f + dz, 0.08f, 2.7f)
        addCyl(c("b0b0b0"), -33.5f, 1.25f, -98f, 0.5f, 0.5f)

        // GODOWN (-40,40)
        building(-40f, 56f, 30f, 20f, 10f, c("7f8c8d"), false)
        val crates = listOf(Pair(-52f, 35f), Pair(-49f, 38.5f), Pair(-30f, 36f), Pair(-45f, 41f), Pair(-33f, 41f))
        for (p in crates) addBox(c("a1743a"), p.first, 1.25f, p.second, 2.5f, 2.5f, 2.5f, true, true)
        addCyl(c("1565c0"), -28f, 0.6f, 32f, 0.9f, 1.2f, true, true)
        addCyl(c("1565c0"), -27f, 0.6f, 33.5f, 0.9f, 1.2f, true, true)

        // HIGHWAY DHABA (120,-40)
        building(120f, -62f, 20f, 10f, 5f, c("c0392b"), false)
        for (px in floatArrayOf(108f, 115f, 125f, 132f)) addBox(c("d9b382"), px, 0.35f, -50f, 2.4f, 0.5f, 1.3f, true, true)
        addBox(c("e67e22"), 142f, 2.4f, -34f, 3.2f, 3.4f, 7f, true, true)   // truck cargo
        addBox(c("16a085"), 142f, 1.6f, -28.5f, 3f, 2.6f, 3f, true, true)   // truck cab

        // PURAANI FACTORY (40,120)
        building(40f, 138f, 34f, 22f, 12f, c("8e9aa0"), false)
        addCyl(c("7f6a5a"), 28f, 15f, 138f, 4f, 30f, true, true)
        for (i in 0 until 3) addCyl(c("c0392b"), 26f + i * 2.2f, 0.6f, 118f, 1.4f, 1.2f, true, true)

        // KABIRA'S HIDEOUT (120,120)
        building(120f, 138f, 26f, 20f, 14f, c("6e1f2b"), true)
        addBox(c("2c2c2c"), 108f, 2f, 112f, 1.2f, 4f, 1.2f, true, true)
        addBox(c("2c2c2c"), 132f, 2f, 112f, 1.2f, 4f, 1.2f, true, true)

        // PARK (40,-40): trees + cricket pitch
        addBox(c("c9b37a"), 40f, 0.06f, -40f, 3f, 0.1f, 20f, false)
        addBox(c("f0f0f0"), 40f, 0.5f, -50f, 0.2f, 1f, 0.2f)
        addBox(c("f0f0f0"), 40f, 0.5f, -30f, 0.2f, 1f, 0.2f)
        val park = listOf(Pair(18f, -62f), Pair(62f, -62f), Pair(18f, -18f), Pair(62f, -18f), Pair(25f, -40f), Pair(55f, -40f))
        for (p in park) tree(p.first, p.second)

        // generic city blocks
        for (bx in cs) for (bz in cs) {
            if (reserved.contains(Pair(bx, bz))) continue
            for (sx in floatArrayOf(-16f, 16f)) for (sz in floatArrayOf(-16f, 16f)) {
                val w = 18f + rnd.nextFloat() * 6f
                val d = 18f + rnd.nextFloat() * 6f
                val h = 8f + rnd.nextFloat() * 24f
                building(bx + sx, bz + sz, w, d, h, palette[rnd.nextInt(palette.size)], true, rnd.nextFloat() < 0.35f)
            }
        }
    }

    /** True if a circle at (x,z) with radius r touches any solid. */
    fun hit(x: Float, z: Float, r: Float): Boolean {
        for (b in colliders) if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true
        return false
    }

    /** Pushes the circle p=[x,z] out of every solid and keeps it in the world. Returns true if anything was hit. */
    fun resolve(p: FloatArray, r: Float): Boolean {
        var hit = false
        for (b in colliders) {
            val nx = p[0].coerceIn(b.x0, b.x1)
            val nz = p[1].coerceIn(b.z0, b.z1)
            val dx = p[0] - nx
            val dz = p[1] - nz
            val d2 = dx * dx + dz * dz
            if (d2 < r * r) {
                hit = true
                if (d2 > 1e-6f) {
                    val d = sqrt(d2)
                    p[0] = nx + dx / d * r
                    p[1] = nz + dz / d * r
                } else {
                    val l = p[0] - b.x0; val rr = b.x1 - p[0]; val t = p[1] - b.z0; val bt = b.z1 - p[1]
                    val m = min(min(l, rr), min(t, bt))
                    if (m == l) p[0] = b.x0 - r
                    else if (m == rr) p[0] = b.x1 + r
                    else if (m == t) p[1] = b.z0 - r
                    else p[1] = b.z1 + r
                }
            }
        }
        if (p[0] < -half) { p[0] = -half; hit = true }
        if (p[0] > half) { p[0] = half; hit = true }
        if (p[1] < -half) { p[1] = -half; hit = true }
        if (p[1] > half) { p[1] = half; hit = true }
        return hit
    }
}
