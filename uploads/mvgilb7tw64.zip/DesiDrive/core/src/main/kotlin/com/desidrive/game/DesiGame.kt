package com.desidrive.game

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.Environment
import com.badlogic.gdx.graphics.g3d.ModelBatch
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight
import com.badlogic.gdx.graphics.g3d.environment.DirectionalShadowLight
import com.badlogic.gdx.graphics.g3d.utils.DepthShaderProvider
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.tan

enum class Quality(val label: String, val drawDist: Float, val npcDist: Float, val shadows: Boolean) {
    LOW("LOW", 80f, 40f, false),
    MEDIUM("MEDIUM", 140f, 70f, true),
    HIGH("HIGH", 210f, 100f, true)
}

class Mission(
    val title: String, val x: Float, val z: Float, val goons: Int, val boss: Boolean,
    val intro: List<String>, val outro: List<String>
)

private class Txt(val s: String, val x: Float, val y: Float, val sc: Float, val col: Color, val center: Boolean)
private class Ptr { var role = 0; var lx = 0f; var ly = 0f }

class DesiGame : ApplicationAdapter() {
    private lateinit var cam: PerspectiveCamera
    private lateinit var uiCam: OrthographicCamera
    private lateinit var modelBatch: ModelBatch
    private lateinit var shadowBatch: ModelBatch
    private lateinit var env: Environment
    private lateinit var shadowLight: DirectionalShadowLight
    private lateinit var shape: ShapeRenderer
    private lateinit var sb: SpriteBatch
    private lateinit var font: BitmapFont
    private lateinit var world: World
    private lateinit var hero: Human
    private lateinit var beam: ModelInstance
    private var logo: Texture? = null
    private val glyph = GlyphLayout()
    private val sky = Color(0.80f, 0.88f, 0.96f, 1f)
    private val skyTop = Color(0.22f, 0.46f, 0.84f, 1f)

    private var W = 1280f; private var H = 720f; private var u = 1f
    private var started = false
    private var quality = Quality.HIGH
    private var settingsOpen = false
    private var mapOpen = false
    private var flipX = true
    private var flipY = true
    private var fov = 65f
    private var hv = 0f
    private var ldx = 0f
    private var ldz = 1f
    private var prefs: com.badlogic.gdx.Preferences? = null
    private var time = 0f

    // entities
    private val heroType = NpcType("Jacky", "14161a", "1c1e22", "c68642", null, Beh.WALK, 1.02f, 1.4f, "hoodie,sun,beard,hair:3a2414,bighair,shoes:f2f2f2")
    private val goonType = NpcType("Kabira ka goon", "1e272e", "485460", "8d5524", "eb4d4b", Beh.WALK)
    private val kabiraType = NpcType("Kabira", "8e1b1b", "1e1e1e", "8d5524", "000000", Beh.WALK, 1.15f)
    private var car: Car? = null
    private val cars = ArrayList<Car>()
    private val npcs = ArrayList<Human>()
    private val goons = ArrayList<Human>()
    private var hp = 100f; private var hurtT = 0f; private var fireCd = 0f; private var hitFlash = 0f

    // input
    private val ptrs = Array(5) { Ptr() }
    private var jx = 0f; private var jy = 0f
    private var gasB = false; private var brakeB = false; private var fireB = false; private var runB = false
    private var lookActive = false
    private var joyActive = false
    private var joyCx = 0f; private var joyCy = 0f; private var joyKx = 0f; private var joyKy = 0f
    private var joyR = 100f

    // camera
    private var camYaw = 0f
    private var camPitch = 18f

    // missions
    private val missions = listOf(
        Mission("Mission 1: Pehla Suraag", -40f, -95f, 0, false,
            listOf("Jacky: Kabira ne Riya ko kidnap kar liya! Main use chhodunga nahi.", "Mandir ke paas chai tapri par jao - chaiwale ko kuch pata hai."),
            listOf("Chaiwala: Saab, Kabira ke aadmi purane godown me dikhe the.", "Godown ki taraf nikalo! (MAP dekho)")),
        Mission("Mission 2: Adda #1 - Godown", -40f, 28f, 3, false,
            listOf("Godown me Kabira ke 3 goon hain. FIRE dabake saaf karo!"),
            listOf("Godown clear! Ek parchi mili: 'Highway dhaba'.")),
        Mission("Mission 3: Adda #2 - Highway Dhaba", 120f, -42f, 4, false,
            listOf("Dhaba door hai - CAR button se gaadi lo aur tez jao!"),
            listOf("Dhaba clear! Naksha mila: Puraani factory.")),
        Mission("Mission 4: Adda #3 - Puraani Factory", 40f, 108f, 5, false,
            listOf("Factory me 5 goon hain. Savdhaan Jacky!"),
            listOf("Factory clear! Kabira ka asli thikana mil gaya.")),
        Mission("Mission 5: Kabira ka Adda", 120f, 106f, 3, true,
            listOf("Yahi hai Kabira ka adda. Riya andar hai!"),
            listOf("Kabira dhher! Riya: Arjun! Tum aa gaye!", "MISSION COMPLETE - Jai Hind!"))
    )
    private var mIdx = 0
    private var phase = 0 // 0 goto, 1 fight, 2 all done
    private val msgs = ArrayList<String>()

    private val vis = ArrayList<ModelInstance>()
    private val casters = ArrayList<ModelInstance>()
    private val texts = ArrayList<Txt>()
    private val p2 = FloatArray(2)
    private val ctr = Vector3()

    override fun create() {
        W = Gdx.graphics.width.toFloat(); H = Gdx.graphics.height.toFloat(); u = H / 720f
        Gfx.setup()
        world = World()
        cam = PerspectiveCamera(65f, W, H)
        cam.near = 0.5f; cam.far = 250f
        uiCam = OrthographicCamera()
        uiCam.setToOrtho(false, W, H)
        modelBatch = ModelBatch()
        shadowBatch = ModelBatch(DepthShaderProvider())
        env = Environment()
        env.set(ColorAttribute(ColorAttribute.AmbientLight, 0.42f, 0.44f, 0.50f, 1f))
        env.set(ColorAttribute(ColorAttribute.Fog, sky.r, sky.g, sky.b, 1f))
        env.add(DirectionalLight().set(0.28f, 0.32f, 0.42f, 0.7f, -0.3f, 0.6f))
        shadowLight = DirectionalShadowLight(2048, 2048, 90f, 90f, 1f, 260f)
        shadowLight.set(1f, 0.95f, 0.85f, -0.6f, -0.8f, -0.4f)
        env.add(shadowLight)
        applyQuality(Quality.HIGH)
        loadPrefs()
        shape = ShapeRenderer()
        sb = SpriteBatch()
        font = BitmapFont()
        font.region.texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        try {
            val t = Texture(Gdx.files.internal("logo.png"), true)
            t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear)
            logo = t
        } catch (e: Exception) { logo = null }

        hero = Human(heroType)
        hero.x = -120f; hero.z = -115f; hero.yaw = 0f

        // cars
        cars.add(Car(CarSpecs.THAR, -148f, -102f, 0f))
        cars.add(Car(CarSpecs.SWIFT, -136f, -102f, 0f))
        cars.add(Car(CarSpecs.FORTUNER, -124f, -102f, 0f))
        cars.add(Car(CarSpecs.HURACAN, -112f, -102f, 0f))
        cars.add(Car(CarSpecs.NEXON, -100f, -102f, 0f))
        cars.add(Car(CarSpecs.AUTO, -88f, -102f, 0f))
        cars.add(Car(CarSpecs.THAR, 3f, -40f, 0f, Color.valueOf("c9c9c9")))
        cars.add(Car(CarSpecs.AUTO, -77f, 20f, 0f))
        cars.add(Car(CarSpecs.HURACAN, 83f, 60f, 180f, Color.valueOf("d63031")))
        cars.add(Car(CarSpecs.SWIFT, -157f, 100f, 0f, Color.valueOf("f5f5f5")))
        cars.add(Car(CarSpecs.AUTO, 40f, 3f, 90f))
        cars.add(Car(CarSpecs.FORTUNER, 105f, 120f, 90f, Color.valueOf("111111")))
        cars.add(Car(CarSpecs.NEXON, 60f, -80f, 90f, Color.valueOf("f5f5f5")))

        spawnNpcs()
        beam = Gfx.beam(Color(1f, 0.85f, 0.1f, 1f), 0.35f)
        queueIntro()
    }

    private fun applyQuality(q: Quality) {
        quality = q
        env.shadowMap = if (q.shadows) shadowLight else null
    }

    private fun spawnNpcs() {
        val rnd = java.util.Random(11)
        // scripted chaiwala next to the stall
        val chai = Human(NPC_TYPES[0]); chai.x = -35.5f; chai.z = -96f; chai.yaw = 120f; npcs.add(chai)
        for (t in NPC_TYPES) {
            val walker = t.beh == Beh.WALK || t.beh == Beh.JOG
            val cnt = if (walker) 5 else 3
            repeat(cnt) {
                val h = Human(t)
                val ri = rnd.nextInt(world.roads.size)
                val side = if (rnd.nextBoolean()) 7.5f else -7.5f
                val line = world.roads[ri] + side
                val ax = rnd.nextBoolean()
                if (walker) {
                    h.axisX = ax; h.fixed = line
                    h.lo = -200f + rnd.nextFloat() * 150f
                    h.hi = h.lo + 60f + rnd.nextFloat() * 80f
                    h.t = h.lo + rnd.nextFloat() * (h.hi - h.lo)
                    h.dir = if (rnd.nextBoolean()) 1f else -1f
                } else {
                    var s = 0f
                    var ok = false
                    while (!ok) {
                        s = -190f + rnd.nextFloat() * 380f
                        ok = world.roads.none { abs(s - it) < 12f }
                    }
                    if (ax) { h.x = s; h.z = line; h.yaw = if (side > 0) 180f else 0f }
                    else { h.x = line; h.z = s; h.yaw = if (side > 0) -90f else 90f }
                }
                npcs.add(h)
            }
        }
    }

    private fun say(s: String) { msgs.add(s) }
    private fun queueIntro() { for (s in missions[mIdx].intro) say(s) }

    // ------------------------------------------------------------ update
    override fun render() {
        val dt = min(Gdx.graphics.deltaTime, 1f / 20f)
        if (!started) { drawMenu(); return }
        time += dt
        update(dt)
        render3D()
        drawHud()
    }

    private fun update(dt: Float) {
        readInput()
        val c = car
        if (c != null) { driveCar(c, dt); hero.x = c.x; hero.z = c.z }
        else walkHero(dt)
        updateNpcs(dt)
        updateGoons(dt)
        updateMission()
        if (hurtT > 0f) hurtT -= dt else if (hp < 100f) hp = min(100f, hp + 3f * dt)
        if (hitFlash > 0f) hitFlash -= dt
        if (hp <= 0f) respawn()
        tickMessages(dt)
        updateCamera(dt)
    }

    private var shownMsg = ""
    private var shownT = 0f
    private fun tickMessages(dt: Float) {
        if (shownT > 0f) { shownT -= dt; return }
        if (msgs.isNotEmpty()) { shownMsg = msgs.removeAt(0); shownT = 4.2f } else shownMsg = ""
    }

    private fun readInput() {
        jx = 0f; jy = 0f; gasB = false; brakeB = false; fireB = false; runB = false
        lookActive = false; joyActive = false
        joyR = 100f * u
        for (i in 0 until 5) {
            val p = ptrs[i]
            if (!Gdx.input.isTouched(i)) { p.role = 0; continue }
            val x = Gdx.input.getX(i).toFloat()
            val y = H - Gdx.input.getY(i).toFloat()
            if (p.role == 0) {
                p.role = classify(x, y); p.lx = x; p.ly = y
                when (p.role) {
                    1 -> { joyCx = x; joyCy = y }
                    5 -> toggleCar()
                    6 -> mapOpen = !mapOpen
                    7 -> settingsOpen = true
                    8 -> settingsClick(x, y)
                }
            }
            when (p.role) {
                1 -> {
                    var dx = (x - joyCx) / joyR; var dy = (y - joyCy) / joyR
                    val l = hypot(dx, dy)
                    if (l > 1f) { dx /= l; dy /= l }
                    jx = dx; jy = dy; joyActive = true
                    joyKx = joyCx + dx * joyR; joyKy = joyCy + dy * joyR
                }
                2 -> {
                    camYaw += (x - p.lx) * 0.22f * (if (flipX) 1f else -1f)
                    camPitch = (camPitch - (y - p.ly) * 0.12f * (if (flipY) 1f else -1f)).coerceIn(6f, 55f)
                    p.lx = x; p.ly = y; lookActive = true
                }
                3 -> if (car != null) gasB = true else fireB = true
                4 -> if (car != null) brakeB = true else runB = true
            }
        }
    }

    private fun d(x1: Float, y1: Float, x2: Float, y2: Float) = hypot(x1 - x2, y1 - y2)

    private fun classify(x: Float, y: Float): Int {
        if (settingsOpen) return 8
        if (mapOpen) return 6
        if (d(x, y, W - 60f * u, H - 55f * u) < 42f * u) return 6
        if (d(x, y, W - 150f * u, H - 55f * u) < 42f * u) return 7
        if (d(x, y, W - 120f * u, 330f * u) < 58f * u) return 5
        if (d(x, y, W - 120f * u, 150f * u) < 74f * u) return 3
        if (d(x, y, W - 270f * u, 110f * u) < 58f * u) return 4
        if (x < W * 0.45f && y < H * 0.78f) return 1
        if (x >= W * 0.45f) return 2
        return 9
    }

    private fun nearestCar(): Car? {
        var best: Car? = null; var bd = 4.8f
        for (c in cars) {
            val dd = hypot(c.x - hero.x, c.z - hero.z)
            if (dd < bd) { bd = dd; best = c }
        }
        return best
    }

    private fun toggleCar() {
        val c = car
        if (c != null) {
            if (abs(c.speed) > 8f) { say("Pehle gaadi roko!"); return }
            c.speed = 0f; c.steer = 0f
            val yr = c.yaw * MathUtils.degreesToRadians
            hero.x = c.x + cos(yr) * (c.spec.wid * 0.5f + 1.1f)
            hero.z = c.z - sin(yr) * (c.spec.wid * 0.5f + 1.1f)
            hero.yaw = c.yaw
            car = null
            collideHero()
        } else {
            val n = nearestCar()
            if (n != null) { car = n; n.speed = 0f; hero.moving = false }
        }
    }

    private fun collideHero() {
        p2[0] = hero.x; p2[1] = hero.z
        repeat(2) {
            world.resolve(p2, 0.45f)
            for (c in cars) {
                val yr = c.yaw * MathUtils.degreesToRadians
                for (s in floatArrayOf(-1f, 1f)) {
                    val cx = c.x + sin(yr) * c.spec.len * 0.27f * s
                    val cz = c.z + cos(yr) * c.spec.len * 0.27f * s
                    val dx = p2[0] - cx; val dz = p2[1] - cz
                    val dd = hypot(dx, dz)
                    val md = c.spec.wid * 0.58f + 0.45f
                    if (dd < md && dd > 0.001f) { p2[0] = cx + dx / dd * md; p2[1] = cz + dz / dd * md }
                }
            }
        }
        hero.x = p2[0]; hero.z = p2[1]
    }

    private fun walkHero(dt: Float) {
        val yr = camYaw * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        val mx = fx * jy + (-fz) * jx
        val mz = fz * jy + fx * jx
        val len = hypot(mx, mz)
        val tgtSp = if (len > 0.12f) (if (runB) 7.5f else if (len > 0.85f) 4.8f else 2.4f) else 0f
        hv += (tgtSp - hv) * min(1f, dt * 9f)
        if (len > 0.12f) {
            ldx = mx / len; ldz = mz / len
            hero.yaw = MathUtils.lerpAngleDeg(hero.yaw, atan2(ldx, ldz) * MathUtils.radiansToDegrees, min(1f, dt * 12f))
        }
        if (hv > 0.15f) {
            hero.x += ldx * hv * dt; hero.z += ldz * hv * dt
            hero.anim += hv * dt * 1.8f
            hero.amp = (14f + hv * 7f).coerceAtMost(58f)
            hero.moving = true
        } else hero.moving = false
        collideHero()

        // shooting: auto-aim nearest goon
        fireCd -= dt
        if (fireB && fireCd <= 0f) {
            var tgt: Human? = null; var bd = 40f
            for (g in goons) if (g.alive) {
                val dd = hypot(g.x - hero.x, g.z - hero.z)
                if (dd < bd) { bd = dd; tgt = g }
            }
            fireCd = 0.28f
            if (tgt != null) {
                hero.yaw = atan2(tgt.x - hero.x, tgt.z - hero.z) * MathUtils.radiansToDegrees
                tgt.hp -= 14f; hitFlash = 0.12f
                if (tgt.hp <= 0f) { tgt.alive = false; say(if (tgt.isBoss) "Kabira gir gaya!" else "Goon dhher!") }
            }
        }
    }

    private fun driveCar(c: Car, dt: Float) {
        val sp = c.spec
        val thr = if (gasB) 1f else if (brakeB) -1f else jy
        var acc = 0f
        if (thr > 0.05f) {
            acc = if (c.speed < -0.5f) sp.brake else sp.accel * thr * (1f - (c.speed / sp.maxSpeed).coerceIn(0f, 1f))
        } else if (thr < -0.05f) {
            acc = if (c.speed > 0.5f) -sp.brake * (-thr)
            else sp.accel * 0.5f * thr * (1f - (-c.speed / (sp.maxSpeed * 0.25f)).coerceIn(0f, 1f))
        }
        c.speed += acc * dt
        c.speed -= c.speed * 0.25f * dt
        if (abs(thr) < 0.05f) c.speed -= sign(c.speed) * min(abs(c.speed), 3f * dt)
        c.speed = c.speed.coerceIn(-sp.maxSpeed * 0.25f, sp.maxSpeed)

        val maxSteer = 0.55f * (1f - min(1f, abs(c.speed) / sp.maxSpeed) * 0.7f)
        c.steer += (jx * maxSteer - c.steer) * min(1f, dt * 7f)
        val yawRate = c.speed / sp.wheelBase * tan(c.steer)
        c.yaw -= yawRate * MathUtils.radiansToDegrees * dt
        val yr = c.yaw * MathUtils.degreesToRadians
        c.x += sin(yr) * c.speed * dt
        c.z += cos(yr) * c.speed * dt
        if (collideCar(c)) c.speed *= max(0f, 1f - 3f * dt)
        if (!lookActive && abs(c.speed) > 1f) camYaw = MathUtils.lerpAngleDeg(camYaw, c.yaw, min(1f, dt * 2.2f))
    }

    private fun collideCar(c: Car): Boolean {
        var hit = false
        repeat(3) {
            val yr = c.yaw * MathUtils.degreesToRadians
            val sx = sin(yr); val sz = cos(yr)
            val off = c.spec.len * 0.27f
            val r = c.spec.wid * 0.58f
            for (s in floatArrayOf(-1f, 1f)) {
                p2[0] = c.x + sx * off * s; p2[1] = c.z + sz * off * s
                val ox = p2[0]; val oz = p2[1]
                if (world.resolve(p2, r)) { hit = true; c.x += p2[0] - ox; c.z += p2[1] - oz }
            }
            for (o in cars) {
                if (o === c) continue
                val dx = c.x - o.x; val dz = c.z - o.z
                val dd = hypot(dx, dz)
                val md = (c.spec.len + o.spec.len) * 0.36f
                if (dd < md && dd > 0.001f) { c.x += dx / dd * (md - dd); c.z += dz / dd * (md - dd); hit = true }
            }
        }
        return hit
    }

    private fun updateNpcs(dt: Float) {
        for (n in npcs) {
            if (n.type.beh == Beh.STAND || n.type.beh == Beh.PHONE) { n.moving = false; continue }
            val sp = n.type.speed * (if (n.type.beh == Beh.JOG) 2.2f else 1f)
            n.t += n.dir * sp * dt
            if (n.t > n.hi) { n.t = n.hi; n.dir = -1f } else if (n.t < n.lo) { n.t = n.lo; n.dir = 1f }
            if (n.axisX) { n.x = n.t; n.z = n.fixed; n.yaw = if (n.dir > 0) 90f else -90f }
            else { n.z = n.t; n.x = n.fixed; n.yaw = if (n.dir > 0) 0f else 180f }
            n.anim += sp * dt * 2.4f
            n.moving = true
        }
    }

    private fun updateGoons(dt: Float) {
        for (g in goons) {
            if (!g.alive) continue
            val dx = hero.x - g.x; val dz = hero.z - g.z
            val dd = hypot(dx, dz)
            if (dd < 45f) {
                g.yaw = MathUtils.lerpAngleDeg(g.yaw, atan2(dx, dz) * MathUtils.radiansToDegrees, min(1f, dt * 8f))
                if (dd > 11f) {
                    val sp = if (g.isBoss) 3.6f else 3.2f
                    g.x += dx / dd * sp * dt; g.z += dz / dd * sp * dt
                    g.anim += sp * dt * 2f; g.moving = true
                } else g.moving = false
                if (dd < 24f) {
                    hp -= (if (g.isBoss) 7f else 4f) * (if (car != null) 0.5f else 1f) * dt
                    hurtT = 0.3f
                }
            } else g.moving = false
            p2[0] = g.x; p2[1] = g.z
            world.resolve(p2, 0.45f)
            g.x = p2[0]; g.z = p2[1]
        }
        goons.removeAll { !it.alive }
    }

    private fun updateMission() {
        val m = missions.getOrNull(mIdx) ?: return
        if (phase == 0) {
            if (hypot(hero.x - m.x, hero.z - m.z) < 7f) {
                if (m.goons == 0 && !m.boss) completeMission(m)
                else { spawnGoons(m); phase = 1; say("Dushman saamne! FIRE button dabao.") }
            }
        } else if (phase == 1) {
            if (goons.none { it.alive }) completeMission(m)
        }
    }

    private fun spawnGoons(m: Mission) {
        goons.clear()
        for (i in 0 until m.goons) {
            val a = i * (6.2832f / max(1, m.goons)) + 0.5f
            val g = Human(goonType)
            g.x = m.x + cos(a) * 9f; g.z = m.z + sin(a) * 9f
            g.hp = 60f
            goons.add(g)
        }
        if (m.boss) {
            val b = Human(kabiraType)
            b.x = m.x; b.z = m.z + 12f; b.hp = 160f; b.isBoss = true
            goons.add(b)
        }
    }

    private fun completeMission(m: Mission) {
        for (s in m.outro) say(s)
        mIdx++
        if (mIdx >= missions.size) { phase = 2 } else { phase = 0; queueIntro() }
    }

    private fun respawn() {
        hp = 100f
        car = null
        hero.x = -120f; hero.z = -115f; hero.yaw = 0f
        goons.clear()
        if (phase == 1) phase = 0
        msgs.clear(); shownT = 0f
        say("Tum gir gaye... Base par wapas. Dobara koshish karo, Jacky!")
    }

    // ------------------------------------------------------------ camera
    private fun updateCamera(dt: Float) {
        val tx = hero.x; val tz = hero.z
        val inCar = car != null
        val ty = if (inCar) 1.4f else 1.6f
        val dist = if (inCar) 9.5f else 5.2f
        val pr = camPitch * MathUtils.degreesToRadians
        val yr = camYaw * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        var dd = dist
        var k = 0.6f
        while (k <= dist) {
            val px = tx - fx * k * cos(pr); val pz = tz - fz * k * cos(pr)
            if (world.hit(px, pz, 0.3f)) { dd = max(1.4f, k - 0.8f); break }
            k += 0.6f
        }
        cam.position.set(tx - fx * dd * cos(pr), ty + dd * sin(pr) + 0.4f, tz - fz * dd * cos(pr))
        cam.up.set(0f, 1f, 0f)
        cam.lookAt(tx, ty, tz)
        val cc = car
        val tf = if (cc != null) 65f + min(1f, abs(cc.speed) / cc.spec.maxSpeed) * 16f else 65f
        fov += (tf - fov) * min(1f, dt * 3f)
        cam.fieldOfView = fov
        cam.far = quality.drawDist + 40f
        cam.update()
    }

    // ------------------------------------------------------------ 3D render
    private fun render3D() {
        vis.clear(); casters.clear()
        val tx = hero.x; val tz = hero.z
        val dd = quality.drawDist
        for (ch in world.chunks) {
            val dx = ch.cx - tx; val dz = ch.cz - tz
            val d2 = dx * dx + dz * dz
            val r = dd + ch.r
            if (d2 < r * r && cam.frustum.sphereInFrustum(ch.cx, ch.cy, ch.cz, ch.r)) vis.add(ch.inst)
            val rs = 70f + ch.r
            if (ch.caster && d2 < rs * rs) casters.add(ch.inst)
        }
        for (c in cars) {
            val dx = c.x - tx; val dz = c.z - tz
            if (dx * dx + dz * dz < dd * dd) { c.layout(); vis.addAll(c.parts); casters.addAll(c.parts) }
        }
        if (car == null) { hero.layout(); vis.addAll(hero.parts); casters.addAll(hero.parts) }
        val nd = quality.npcDist
        for (n in npcs) {
            val dx = n.x - tx; val dz = n.z - tz
            if (dx * dx + dz * dz < nd * nd) { n.layout(); vis.addAll(n.parts); casters.addAll(n.parts) }
        }
        for (g in goons) if (g.alive) { g.layout(); vis.addAll(g.parts); casters.addAll(g.parts) }
        val m = missions.getOrNull(mIdx)
        if (m != null && phase == 0) {
            beam.transform.setToTranslation(m.x, 20f, m.z).scale(3f, 40f, 3f)
            vis.add(beam)
        }

        if (quality.shadows) {
            ctr.set(tx, 0f, tz)
            shadowLight.begin(ctr, cam.direction)
            shadowBatch.begin(shadowLight.camera)
            shadowBatch.render(casters)
            shadowBatch.end()
            shadowLight.end()
        }
        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(sky.r, sky.g, sky.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)
        drawSky()
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
        modelBatch.begin(cam)
        modelBatch.render(vis, env)
        modelBatch.end()
    }

    private fun drawSky() {
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        shape.projectionMatrix = uiCam.combined
        val phi = asin((-cam.direction.y).coerceIn(-0.99f, 0.99f))
        val tf = tan(cam.fieldOfView * 0.5f * MathUtils.degreesToRadians)
        val hy = (H * 0.5f + tan(phi) / tf * H * 0.5f).coerceIn(H * 0.15f, H * 1.6f)
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(sky)
        shape.rect(0f, 0f, W, min(hy, H))
        if (hy < H) {
            shape.rect(0f, hy, W, H - hy, sky, sky, skyTop, skyTop)
            val sx = W * 0.74f; val sy = hy + (H - hy) * 0.62f
            shape.setColor(1f, 0.95f, 0.75f, 0.14f); shape.circle(sx, sy, 95f * u, 40)
            shape.setColor(1f, 0.96f, 0.8f, 0.25f); shape.circle(sx, sy, 62f * u, 40)
            shape.setColor(1f, 0.98f, 0.88f, 1f); shape.circle(sx, sy, 30f * u, 32)
            for (i in 0 until 6) {
                val cx = (((i * 0.21f + time * 0.006f) % 1.25f) - 0.12f) * W
                val cy = hy + (H - hy) * (0.22f + 0.13f * (i % 4))
                shape.setColor(1f, 1f, 1f, 0.55f)
                shape.circle(cx, cy, 26f * u, 20); shape.circle(cx + 30f * u, cy + 6f * u, 32f * u, 20)
                shape.circle(cx + 64f * u, cy, 24f * u, 20); shape.circle(cx + 30f * u, cy - 10f * u, 22f * u, 20)
            }
        }
        shape.end()
    }

    // ------------------------------------------------------------ HUD helpers
    private fun text(s: String, x: Float, y: Float, sc: Float, col: Color = Color.WHITE, center: Boolean = true) {
        texts.add(Txt(s, x, y, sc, col, center))
    }

    private fun flushTexts() {
        sb.begin()
        for (t in texts) {
            font.data.setScale(t.sc * u)
            font.color = t.col
            glyph.setText(font, t.s)
            val tx = if (t.center) t.x - glyph.width / 2f else t.x
            font.draw(sb, t.s, tx, t.y + glyph.height / 2f)
        }
        sb.end()
        texts.clear()
    }

    // kinds: 1 gas, 2 fire, 3 brake, 4 run, 5 car, 6 exit, 7 map, 8 settings
    private fun btn(cx: Float, cy: Float, r: Float, kind: Int, on: Boolean) {
        val col = when (kind) {
            1 -> floatArrayOf(0.15f, 0.75f, 0.30f)
            2 -> floatArrayOf(1f, 0.50f, 0.10f)
            3 -> floatArrayOf(0.90f, 0.20f, 0.20f)
            4 -> floatArrayOf(0.20f, 0.60f, 1f)
            5 -> floatArrayOf(0.95f, 0.80f, 0.15f)
            6 -> floatArrayOf(0.90f, 0.40f, 0.20f)
            else -> floatArrayOf(0.55f, 0.58f, 0.68f)
        }
        val rr = r * (if (on) 1f + 0.06f * sin(time * 14f) else 1f)
        if (on) {
            val ph = (time * 1.5f) % 1f
            shape.setColor(col[0], col[1], col[2], 0.55f * (1f - ph))
            shape.circle(cx, cy, r * (1f + 0.4f * ph), 36)
        }
        shape.setColor(1f, 1f, 1f, if (on) 0.95f else 0.6f)
        shape.circle(cx, cy, rr, 36)
        val k = if (on) 0.8f else 0.5f
        shape.setColor(col[0] * k, col[1] * k, col[2] * k, 0.92f)
        shape.circle(cx, cy, rr - 3.5f * u, 36)
        val s = rr * 0.5f
        val dr = col[0] * 0.4f; val dg = col[1] * 0.4f; val db = col[2] * 0.4f
        shape.setColor(1f, 1f, 1f, 0.97f)
        when (kind) {
            1 -> for (i in 0..1) {
                val y0 = cy - 0.55f * s + i * 0.6f * s + (if (on) sin(time * 10f) * 0.12f * s else 0f)
                shape.rectLine(cx - 0.75f * s, y0, cx, y0 + 0.6f * s, 0.26f * s)
                shape.rectLine(cx, y0 + 0.6f * s, cx + 0.75f * s, y0, 0.26f * s)
            }
            2 -> {
                shape.circle(cx, cy, 0.85f * s, 28)
                shape.setColor(dr, dg, db, 1f); shape.circle(cx, cy, 0.60f * s, 28)
                shape.setColor(1f, 1f, 1f, 0.97f); shape.circle(cx, cy, 0.20f * s, 16)
                shape.rectLine(cx - 1.15f * s, cy, cx - 0.35f * s, cy, 0.14f * s)
                shape.rectLine(cx + 0.35f * s, cy, cx + 1.15f * s, cy, 0.14f * s)
                shape.rectLine(cx, cy - 1.15f * s, cx, cy - 0.35f * s, 0.14f * s)
                shape.rectLine(cx, cy + 0.35f * s, cx, cy + 1.15f * s, 0.14f * s)
            }
            3 -> shape.rect(cx - 0.55f * s, cy - 0.55f * s, 1.1f * s, 1.1f * s)
            4 -> {
                shape.triangle(cx - 0.2f * s, cy + 0.9f * s, cx - 0.5f * s, cy - 0.1f * s, cx + 0.1f * s, cy - 0.1f * s)
                shape.triangle(cx + 0.2f * s, cy - 0.9f * s, cx + 0.5f * s, cy + 0.1f * s, cx - 0.1f * s, cy + 0.1f * s)
            }
            5 -> {
                shape.rect(cx - 0.95f * s, cy - 0.30f * s, 1.9f * s, 0.55f * s)
                shape.rect(cx - 0.50f * s, cy + 0.20f * s, 1.0f * s, 0.40f * s)
                shape.setColor(dr, dg, db, 1f)
                shape.circle(cx - 0.55f * s, cy - 0.32f * s, 0.27f * s, 16)
                shape.circle(cx + 0.55f * s, cy - 0.32f * s, 0.27f * s, 16)
                shape.setColor(1f, 1f, 1f, 0.97f)
                shape.circle(cx - 0.55f * s, cy - 0.32f * s, 0.12f * s, 12)
                shape.circle(cx + 0.55f * s, cy - 0.32f * s, 0.12f * s, 12)
            }
            6 -> {
                shape.rect(cx - 0.95f * s, cy - 0.75f * s, 0.30f * s, 1.5f * s)
                shape.rectLine(cx - 0.4f * s, cy, cx + 0.45f * s, cy, 0.24f * s)
                shape.triangle(cx + 0.95f * s, cy, cx + 0.40f * s, cy + 0.45f * s, cx + 0.40f * s, cy - 0.45f * s)
            }
            7 -> {
                shape.circle(cx, cy + 0.2f * s, 0.55f * s, 20)
                shape.triangle(cx - 0.45f * s, cy + 0.02f * s, cx + 0.45f * s, cy + 0.02f * s, cx, cy - 0.9f * s)
                shape.setColor(dr, dg, db, 1f); shape.circle(cx, cy + 0.2f * s, 0.2f * s, 12)
            }
            else -> {
                for (i in 0 until 8) {
                    val a = i * MathUtils.PI / 4f
                    shape.rectLine(cx + cos(a) * 0.55f * s, cy + sin(a) * 0.55f * s, cx + cos(a) * 1.05f * s, cy + sin(a) * 1.05f * s, 0.34f * s)
                }
                shape.circle(cx, cy, 0.72f * s, 20)
                shape.setColor(dr, dg, db, 1f); shape.circle(cx, cy, 0.30f * s, 14)
            }
        }
    }

    private fun drawMenu() {
        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(0.05f, 0.08f, 0.15f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        shape.projectionMatrix = uiCam.combined
        sb.projectionMatrix = uiCam.combined
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(1f, 0.6f, 0.2f, 1f); shape.rect(0f, H - 14f * u, W, 14f * u)
        shape.setColor(1f, 1f, 1f, 1f); shape.rect(0f, H - 28f * u, W, 14f * u)
        shape.setColor(0.07f, 0.53f, 0.03f, 1f); shape.rect(0f, H - 42f * u, W, 14f * u)
        shape.end()
        val lg = logo
        if (lg != null) {
            val ls = H * 0.58f
            sb.begin()
            sb.draw(lg, W / 2f - ls / 2f, H * 0.38f, ls, ls)
            sb.end()
        } else {
            text("DESI DRIVER", W / 2f, H * 0.68f, 4.5f, Color(1f, 0.75f, 0.2f, 1f))
        }
        text("Left: move / steer    Right swipe: camera    CAR: gaadi me baitho    FIRE: goli", W / 2f, H * 0.30f, 1.1f, Color.LIGHT_GRAY)
        if ((System.currentTimeMillis() / 500L) % 2L == 0L)
            text("TAP TO START", W / 2f, H * 0.18f, 2.2f)
        flushTexts()
        if (Gdx.input.justTouched()) started = true
    }

    private fun drawHud() {
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        shape.projectionMatrix = uiCam.combined
        sb.projectionMatrix = uiCam.combined
        if (hurtT > 0f) {
            shape.begin(ShapeRenderer.ShapeType.Filled)
            shape.setColor(0.8f, 0f, 0f, min(0.35f, hurtT))
            shape.rect(0f, 0f, W, H)
            shape.end()
        }
        if (mapOpen) { drawFullMap(); return }
        drawMiniMap()
        drawControls()
        drawInfo()
        if (settingsOpen) drawSettings()
    }

    private fun drawControls() {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        val bx = if (joyActive) joyCx else 150f * u
        val by = if (joyActive) joyCy else 150f * u
        shape.setColor(1f, 1f, 1f, 0.16f); shape.circle(bx, by, joyR, 40)
        shape.setColor(1f, 1f, 1f, 0.42f)
        shape.circle(if (joyActive) joyKx else bx, if (joyActive) joyKy else by, 46f * u, 32)
        val inCar = car != null
        btn(W - 120f * u, 150f * u, 70f * u, if (inCar) 1 else 2, gasB || fireB)
        btn(W - 270f * u, 110f * u, 55f * u, if (inCar) 3 else 4, brakeB || runB)
        btn(W - 120f * u, 330f * u, 55f * u, if (inCar) 6 else 5, inCar || nearestCar() != null)
        btn(W - 60f * u, H - 55f * u, 40f * u, 7, false)
        btn(W - 150f * u, H - 55f * u, 40f * u, 8, false)
        shape.end()
        flushTexts()
    }

    private fun drawInfo() {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        val bw = 280f * u; val bh = 16f * u
        val bx = W / 2f - bw / 2f; val by = H - 34f * u
        shape.setColor(0f, 0f, 0f, 0.5f); shape.rect(bx - 3f * u, by - 3f * u, bw + 6f * u, bh + 6f * u)
        val f = (hp / 100f).coerceIn(0f, 1f)
        shape.setColor(1f - f, f, 0.15f, 0.95f); shape.rect(bx, by, bw * f, bh)
        // mission panel
        val m = missions.getOrNull(mIdx)
        shape.setColor(0f, 0f, 0f, 0.45f)
        shape.rect(W / 2f - 230f * u, H - 112f * u, 460f * u, 62f * u)
        // message banner
        if (shownMsg.isNotEmpty()) {
            shape.setColor(0f, 0f, 0f, 0.6f)
            shape.rect(W / 2f - 330f * u, 20f * u, 660f * u, 56f * u)
        }
        shape.end()
        text("HP", bx - 22f * u, by + bh / 2f, 1.1f)
        if (m != null) {
            text(m.title, W / 2f, H - 68f * u, 1.25f, Color(1f, 0.85f, 0.2f, 1f))
            val dist = hypot(m.x - hero.x, m.z - hero.z).toInt()
            val obj = if (phase == 0) "Marker tak jao: ${dist}m" else "Goons bache: ${goons.count { it.alive }}"
            text(obj, W / 2f, H - 96f * u, 1.1f)
        } else {
            text("Free roam - Jai Hind!", W / 2f, H - 82f * u, 1.3f, Color(0.5f, 1f, 0.5f, 1f))
        }
        if (shownMsg.isNotEmpty()) text(shownMsg, W / 2f, 48f * u, 1.1f)
        val c = car
        if (c != null) {
            text("${(abs(c.speed) * 3.6f).toInt()} km/h", W / 2f, 110f * u, 2f)
            text(c.spec.name, W / 2f, 140f * u, 1f, Color.LIGHT_GRAY)
        }
        if (hitFlash > 0f) text("+", W / 2f, H / 2f, 2.5f, Color.RED)
        flushTexts()
    }

    // GTA San Andreas style radar: round, rotates with the camera heading (up = where you look), black & white
    private fun drawMiniMap() {
        val R = 88f * u
        val cx = 20f * u + R
        val cy = H - R - 22f * u
        val yr = camYaw * MathUtils.degreesToRadians
        val sy = sin(yr); val cw = cos(yr)
        val sc = (if (car != null) 0.8f else 1.25f) * u
        val hx = hero.x; val hz = hero.z
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0f, 0f, 0f, 0.55f); shape.circle(cx + 3f * u, cy - 3f * u, R + 6f * u, 48)
        shape.setColor(1f, 1f, 1f, 0.95f); shape.circle(cx, cy, R + 4f * u, 48)
        shape.setColor(0.08f, 0.08f, 0.09f, 1f); shape.circle(cx, cy, R, 48)
        shape.end()
        Gdx.gl.glClear(GL20.GL_STENCIL_BUFFER_BIT)
        Gdx.gl.glEnable(GL20.GL_STENCIL_TEST)
        Gdx.gl.glColorMask(false, false, false, false)
        Gdx.gl.glStencilFunc(GL20.GL_ALWAYS, 1, 0xFF)
        Gdx.gl.glStencilOp(GL20.GL_REPLACE, GL20.GL_REPLACE, GL20.GL_REPLACE)
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.circle(cx, cy, R, 48)
        shape.end()
        Gdx.gl.glColorMask(true, true, true, true)
        Gdx.gl.glStencilFunc(GL20.GL_EQUAL, 1, 0xFF)
        Gdx.gl.glStencilOp(GL20.GL_KEEP, GL20.GL_KEEP, GL20.GL_KEEP)
        shape.begin(ShapeRenderer.ShapeType.Filled)
        // roads
        shape.setColor(0.58f, 0.58f, 0.60f, 1f)
        for (r in world.roads) {
            val ax = r - hx; val az1 = -220f - hz; val az2 = 220f - hz
            shape.rectLine(cx + (-cw * ax + sy * az1) * sc, cy + (sy * ax + cw * az1) * sc,
                cx + (-cw * ax + sy * az2) * sc, cy + (sy * ax + cw * az2) * sc, 12f * sc)
            val bz = r - hz; val bx1 = -220f - hx; val bx2 = 220f - hx
            shape.rectLine(cx + (-cw * bx1 + sy * bz) * sc, cy + (sy * bx1 + cw * bz) * sc,
                cx + (-cw * bx2 + sy * bz) * sc, cy + (sy * bx2 + cw * bz) * sc, 12f * sc)
        }
        // buildings
        val lim = R / sc + 40f
        for (b in world.mapRects) {
            if (hypot((b.x0 + b.x1) * 0.5f - hx, (b.z0 + b.z1) * 0.5f - hz) > lim) continue
            val l = 0.18f + (b.c.r + b.c.g + b.c.b) / 3f * 0.12f
            shape.setColor(l, l, l + 0.01f, 1f)
            val x0 = b.x0 - hx; val x1 = b.x1 - hx; val z0 = b.z0 - hz; val z1 = b.z1 - hz
            val ax = cx + (-cw * x0 + sy * z0) * sc; val ay = cy + (sy * x0 + cw * z0) * sc
            val bx = cx + (-cw * x1 + sy * z0) * sc; val by = cy + (sy * x1 + cw * z0) * sc
            val ex = cx + (-cw * x1 + sy * z1) * sc; val ey = cy + (sy * x1 + cw * z1) * sc
            val dx = cx + (-cw * x0 + sy * z1) * sc; val dy = cy + (sy * x0 + cw * z1) * sc
            shape.triangle(ax, ay, bx, by, ex, ey)
            shape.triangle(ax, ay, ex, ey, dx, dy)
        }
        // enemies
        shape.setColor(1f, 0.15f, 0.15f, 1f)
        for (g in goons) if (g.alive) {
            val gx = g.x - hx; val gz = g.z - hz
            shape.circle(cx + (-cw * gx + sy * gz) * sc, cy + (sy * gx + cw * gz) * sc, 3.5f * u, 10)
        }
        // mission marker (clamped to the radar edge)
        val m = missions.getOrNull(mIdx)
        if (m != null && phase == 0) {
            val mx0 = m.x - hx; val mz0 = m.z - hz
            var mx = (-cw * mx0 + sy * mz0) * sc; var my = (sy * mx0 + cw * mz0) * sc
            val d = hypot(mx, my); val edge = R - 8f * u
            if (d > edge) { mx *= edge / d; my *= edge / d }
            shape.setColor(1f, 0.85f, 0.1f, 1f); shape.circle(cx + mx, cy + my, 6.5f * u, 16)
        }
        // player arrow (always points up)
        shape.setColor(0f, 0f, 0f, 1f)
        shape.triangle(cx, cy + 13f * u, cx - 9.5f * u, cy - 9f * u, cx + 9.5f * u, cy - 9f * u)
        shape.setColor(1f, 1f, 1f, 1f)
        shape.triangle(cx, cy + 10f * u, cx - 6.5f * u, cy - 6f * u, cx + 6.5f * u, cy - 6f * u)
        shape.end()
        Gdx.gl.glDisable(GL20.GL_STENCIL_TEST)
        // north marker follows world north while the map rotates
        text("N", cx + sy * (R - 11f * u), cy + cw * (R - 11f * u), 1.0f, Color.WHITE)
    }

    private fun arrow(px: Float, py: Float, yawDeg: Float, size: Float) {
        val yr = yawDeg * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        shape.setColor(1f, 1f, 1f, 1f)
        shape.triangle(
            px + fx * size, py + fz * size,
            px - fx * size * 0.6f + fz * size * 0.6f, py - fz * size * 0.6f - fx * size * 0.6f,
            px - fx * size * 0.6f - fz * size * 0.6f, py - fz * size * 0.6f + fx * size * 0.6f
        )
    }

    private fun drawFullMap() {
        val size = H * 0.86f
        val x0 = (W - size) / 2f; val y0 = (H - size) / 2f
        val sc = size / 440f
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0f, 0f, 0f, 0.82f); shape.rect(0f, 0f, W, H)
        shape.setColor(0.09f, 0.09f, 0.10f, 1f); shape.rect(x0, y0, size, size)
        shape.setColor(0.58f, 0.58f, 0.60f, 1f)
        for (r in world.roads) {
            shape.rect(x0 + (r + 220f - 6f) * sc, y0, 12f * sc, size)
            shape.rect(x0, y0 + (r + 220f - 6f) * sc, size, 12f * sc)
        }
        for (b in world.mapRects) {
            val l = 0.18f + (b.c.r + b.c.g + b.c.b) / 3f * 0.12f
            shape.setColor(l, l, l + 0.01f, 1f)
            shape.rect(x0 + (b.x0 + 220f) * sc, y0 + (b.z0 + 220f) * sc, (b.x1 - b.x0) * sc, (b.z1 - b.z0) * sc)
        }
        for ((i, m) in missions.withIndex()) {
            if (i < mIdx) shape.setColor(0.35f, 0.35f, 0.35f, 1f)
            else if (i == mIdx) shape.setColor(1f, 0.85f, 0.1f, 1f)
            else shape.setColor(0.85f, 0.85f, 0.85f, 1f)
            shape.circle(x0 + (m.x + 220f) * sc, y0 + (m.z + 220f) * sc, 7f * u, 16)
        }
        arrow(x0 + (hero.x + 220f) * sc, y0 + (hero.z + 220f) * sc, hero.yaw, 11f * u)
        shape.end()
        for ((i, m) in missions.withIndex()) {
            text("${i + 1}", x0 + (m.x + 220f) * sc, y0 + (m.z + 220f) * sc, 1f, Color.BLACK)
        }
        text("MAP  -  tap karke band karo", W / 2f, y0 + size + 4f * u, 1.1f)
        flushTexts()
    }

    // settings panel layout (shared by draw + click)
    private fun sPanel() = floatArrayOf(W / 2f - 310f * u, H / 2f - 220f * u, 620f * u, 440f * u)
    private fun qBtn(i: Int): FloatArray {
        val p = sPanel()
        return floatArrayOf(p[0] + 30f * u + i * 190f * u, p[1] + p[3] - 190f * u, 170f * u, 64f * u)
    }
    private fun tBtn(i: Int): FloatArray {
        val p = sPanel()
        return floatArrayOf(p[0] + 20f * u + i * 300f * u, p[1] + 110f * u, 280f * u, 56f * u)
    }
    private fun closeBtn(): FloatArray {
        val p = sPanel()
        return floatArrayOf(p[0] + p[2] / 2f - 100f * u, p[1] + 30f * u, 200f * u, 60f * u)
    }
    private fun inRect(x: Float, y: Float, r: FloatArray) = x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]

    private fun settingsClick(x: Float, y: Float) {
        for ((i, q) in Quality.values().withIndex()) if (inRect(x, y, qBtn(i))) { applyQuality(q); savePrefs(); return }
        if (inRect(x, y, tBtn(0))) { flipX = !flipX; savePrefs(); return }
        if (inRect(x, y, tBtn(1))) { flipY = !flipY; savePrefs(); return }
        if (inRect(x, y, closeBtn())) settingsOpen = false
    }

    private fun loadPrefs() {
        val pr = Gdx.app.getPreferences("desidrive")
        prefs = pr
        flipX = pr.getBoolean("flipX", true)
        flipY = pr.getBoolean("flipY", true)
        applyQuality(Quality.values()[pr.getInteger("quality", 2).coerceIn(0, 2)])
    }

    private fun savePrefs() {
        val pr = prefs ?: return
        pr.putBoolean("flipX", flipX)
        pr.putBoolean("flipY", flipY)
        pr.putInteger("quality", quality.ordinal)
        pr.flush()
    }

    private fun drawSettings() {
        val p = sPanel()
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0f, 0f, 0f, 0.55f); shape.rect(0f, 0f, W, H)
        shape.setColor(0.1f, 0.13f, 0.2f, 0.97f); shape.rect(p[0], p[1], p[2], p[3])
        for ((i, q) in Quality.values().withIndex()) {
            val b = qBtn(i)
            if (q == quality) shape.setColor(1f, 0.6f, 0.15f, 1f) else shape.setColor(0.25f, 0.3f, 0.4f, 1f)
            shape.rect(b[0], b[1], b[2], b[3])
        }
        for (i in 0..1) {
            val b = tBtn(i)
            val on = if (i == 0) flipX else flipY
            if (on) shape.setColor(0.2f, 0.5f, 0.75f, 1f) else shape.setColor(0.25f, 0.3f, 0.4f, 1f)
            shape.rect(b[0], b[1], b[2], b[3])
        }
        val cb = closeBtn()
        shape.setColor(0.2f, 0.55f, 0.3f, 1f); shape.rect(cb[0], cb[1], cb[2], cb[3])
        shape.end()
        text("SETTINGS", p[0] + p[2] / 2f, p[1] + p[3] - 40f * u, 1.8f)
        text("Graphics quality", p[0] + p[2] / 2f, p[1] + p[3] - 110f * u, 1.2f, Color.LIGHT_GRAY)
        for ((i, q) in Quality.values().withIndex()) {
            val b = qBtn(i)
            text(q.label, b[0] + b[2] / 2f, b[1] + b[3] / 2f, 1.2f)
        }
        for (i in 0..1) {
            val b = tBtn(i)
            val on = if (i == 0) flipX else flipY
            text((if (i == 0) "Camera X: " else "Camera Y: ") + (if (on) "FLIPPED" else "ORIGINAL"), b[0] + b[2] / 2f, b[1] + b[3] / 2f, 1.0f)
        }
        text(if (quality.shadows) "Shadows: ON   Draw distance: ${quality.drawDist.toInt()}m" else "Shadows: OFF   Draw distance: ${quality.drawDist.toInt()}m",
            p[0] + p[2] / 2f, p[1] + 200f * u, 1f, Color.LIGHT_GRAY)
        text("CLOSE", cb[0] + cb[2] / 2f, cb[1] + cb[3] / 2f, 1.2f)
        flushTexts()
    }

    override fun resize(width: Int, height: Int) {
        W = width.toFloat(); H = height.toFloat(); u = H / 720f
        if (this::cam.isInitialized) { cam.viewportWidth = W; cam.viewportHeight = H; cam.update() }
        if (this::uiCam.isInitialized) { uiCam.setToOrtho(false, W, H) }
    }

    override fun dispose() {
        modelBatch.dispose(); shadowBatch.dispose(); shadowLight.dispose()
        shape.dispose(); sb.dispose(); font.dispose()
        logo?.dispose()
        Gfx.dispose()
    }
}
