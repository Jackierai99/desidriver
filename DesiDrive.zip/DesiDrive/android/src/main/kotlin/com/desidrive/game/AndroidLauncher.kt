package com.desidrive.game

import android.os.Bundle
import com.badlogic.gdx.backends.android.AndroidApplication
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration

class AndroidLauncher : AndroidApplication() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = AndroidApplicationConfiguration()
        cfg.useImmersiveMode = true
        cfg.numSamples = 2
        cfg.useWakelock = true
        initialize(DesiGame(), cfg)
    }
}
