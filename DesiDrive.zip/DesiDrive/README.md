# Desidriver - Mission Hindustan

## Kya naya hai (v0.2 - 3D upgrade)
- Cars ab smooth rounded body (curved hood/roof/boot), glass cabin, headlight/taillight glow, grille, mirrors, wheel arches
- Alloy wheels jo ghoomte hain, aage ke wheels steer karte hain, body brake/turn pe jhukti hai
- Super GT me spoiler, Auto Rickshaw me asli 3-wheeler shape (canopy, seat, handlebar)
- City: textured sadak (lane marking, zebra crossing), footpath tiles, textured khidkiyan wali buildings, shop shutters, parapet, tanks, street lamps, bade ghane ped
- Sky gradient + sun + clouds, 2 lights + shadows + fog
- Saari static city ek-do bade meshes me merge -> FPS zyada
- Speed ke saath FOV badhta hai
- Camera control fix: ab SET me "Camera X" / "Camera Y" toggle hai (ulta lage to ek tap me palat do)

## APK GitHub se banana
1. Naya GitHub repo banao.
2. Is poore folder ki files repo me upload karo (ya DesiDrive.zip hi upload kar do - workflow khud unzip kar lega).
   `.github/workflows/build.yml` repo ke root me hona chahiye.
3. Repo -> Actions tab -> "Build APK" -> Run workflow (ya bas push karo).
4. 5-8 min baad APK milegi: Actions run ke Artifacts me `DesiDrive-debug-apk`, aur repo ke Releases me `latest`.

## Real 3D car models lagana (optional)
`android/src/main/assets/models/` folder banao aur ye files daalo (.obj + .mtl + textures):
`sedan.obj`, `suv.obj`, `supercar.obj`, `auto.obj`
- Car ka front +Z ki taraf hona chahiye (Blender export: Forward = Z)
- Size apne aap car ki length ke hisaab se scale ho jata hai
- File mili to built-in model ki jagah wahi use hoga; nahi mili to built-in model chalta rahega
Free CC0 models: kenney.nl, quaternius.com, poly.pizza
