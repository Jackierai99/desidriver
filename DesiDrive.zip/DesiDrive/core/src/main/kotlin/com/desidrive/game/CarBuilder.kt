package com.desidrive.game

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.FloatAttribute
import com.badlogic.gdx.graphics.g3d.attributes.IntAttribute
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

class CarModel(val body: Model, val wheel: Model)

/**
 * Builds smooth, rounded cars in code: lofted superellipse cross-sections with smooth normals,
 * glass greenhouse, lights, grille, mirrors, wheel arches + separate alloy wheels.
 */
object CarBuilder {
    private class Sec(val z: Float, val hw: Float, val yb: Float, val yt: Float)

    private val tm = Matrix4()
    private val ia = MeshPartBuilder.VertexInfo()
    private val ib = MeshPartBuilder.VertexInfo()
    private val ic = MeshPartBuilder.VertexInfo()
    private val id = MeshPartBuilder.VertexInfo()
    private val t1 = Vector3()
    private val t2 = Vector3()

    // columns: zFrac, halfWidthFrac, bottomFrac, topFrac   (front = +z, listed front -> rear)
    private val SEDAN_BODY = arrayOf(
        floatArrayOf(.50f, .62f, .30f, .58f), floatArrayOf(.485f, .84f, .12f, .76f), floatArrayOf(.44f, .96f, .0f, .88f),
        floatArrayOf(.30f, 1f, .0f, .93f), floatArrayOf(.12f, 1f, .0f, .96f), floatArrayOf(-.10f, 1f, .0f, .97f),
        floatArrayOf(-.30f, 1f, .0f, .98f), floatArrayOf(-.43f, .98f, .04f, .95f), floatArrayOf(-.485f, .88f, .12f, .82f),
        floatArrayOf(-.50f, .66f, .28f, .62f)
    )
    private val SUV_BODY = arrayOf(
        floatArrayOf(.50f, .70f, .25f, .62f), floatArrayOf(.485f, .88f, .10f, .80f), floatArrayOf(.44f, .98f, .0f, .90f),
        floatArrayOf(.30f, 1f, .0f, .94f), floatArrayOf(.10f, 1f, .0f, .97f), floatArrayOf(-.20f, 1f, .0f, 1f),
        floatArrayOf(-.44f, 1f, .0f, 1f), floatArrayOf(-.485f, .94f, .06f, .97f), floatArrayOf(-.50f, .80f, .20f, .85f)
    )
    private val SUPER_BODY = arrayOf(
        floatArrayOf(.50f, .72f, .30f, .50f), floatArrayOf(.48f, .92f, .10f, .62f), floatArrayOf(.42f, 1f, .0f, .70f),
        floatArrayOf(.25f, 1.02f, .0f, .78f), floatArrayOf(.05f, 1.03f, .0f, .84f), floatArrayOf(-.15f, 1.04f, .0f, .88f),
        floatArrayOf(-.35f, 1.06f, .0f, .90f), floatArrayOf(-.46f, 1.04f, .04f, .86f), floatArrayOf(-.50f, .92f, .14f, .76f)
    )
    private val AUTO_BODY = arrayOf(
        floatArrayOf(.50f, .30f, .40f, .80f), floatArrayOf(.44f, .55f, .20f, .95f), floatArrayOf(.34f, .78f, .10f, 1f),
        floatArrayOf(.18f, .92f, .0f, 1f), floatArrayOf(.0f, .98f, .0f, .95f), floatArrayOf(-.20f, 1f, .0f, .72f),
        floatArrayOf(-.40f, 1f, .0f, .70f), floatArrayOf(-.50f, .95f, .06f, .68f)
    )
    // cabin: zFrac, halfWidthFrac, topFrac (of cabinH)
    private val SEDAN_CAB = arrayOf(
        floatArrayOf(.16f, .88f, .08f), floatArrayOf(.04f, .82f, .78f), floatArrayOf(-.10f, .80f, 1f),
        floatArrayOf(-.22f, .80f, 1f), floatArrayOf(-.33f, .84f, .72f), floatArrayOf(-.40f, .90f, .18f)
    )
    private val SUV_CAB = arrayOf(
        floatArrayOf(.14f, .90f, .10f), floatArrayOf(.06f, .86f, .75f), floatArrayOf(-.02f, .84f, 1f),
        floatArrayOf(-.38f, .84f, 1f), floatArrayOf(-.46f, .88f, .78f), floatArrayOf(-.49f, .90f, .20f)
    )
    private val SUPER_CAB = arrayOf(
        floatArrayOf(.12f, .88f, .06f), floatArrayOf(-.02f, .80f, .85f), floatArrayOf(-.12f, .76f, 1f),
        floatArrayOf(-.26f, .74f, .90f), floatArrayOf(-.40f, .84f, .30f)
    )

    private fun sgn(v: Float) = if (v < 0f) -1f else 1f

    private fun nocull(m: Material): Material { m.set(IntAttribute.createCullFace(0)); return m }

    private fun paint(c: Color) = nocull(Material(
        ColorAttribute.createDiffuse(c), ColorAttribute.createSpecular(0.85f, 0.85f, 0.85f, 1f), FloatAttribute.createShininess(48f)))
    private fun glassMat() = nocull(Material(
        ColorAttribute.createDiffuse(0.06f, 0.09f, 0.13f, 1f), ColorAttribute.createSpecular(1f, 1f, 1f, 1f), FloatAttribute.createShininess(90f)))
    private fun dull(r: Float, g: Float, b: Float, sp: Float = 0.2f, sh: Float = 10f) = Material(
        ColorAttribute.createDiffuse(r, g, b, 1f), ColorAttribute.createSpecular(sp, sp, sp, 1f), FloatAttribute.createShininess(sh))
    private fun chromeMat() = dull(0.78f, 0.80f, 0.83f, 1f, 60f)
    private fun lightMat(r: Float, g: Float, b: Float, er: Float, eg: Float, eb: Float): Material {
        val m = Material(ColorAttribute.createDiffuse(r, g, b, 1f), ColorAttribute.createSpecular(1f, 1f, 1f, 1f), FloatAttribute.createShininess(80f))
        m.set(ColorAttribute.createEmissive(er, eg, eb, 1f))
        return m
    }

    // ------------------------------------------------------------ primitive helpers (always reset transform!)
    private fun box(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, rx: Float = 0f) {
        tm.idt().translate(cx, cy, cz)
        if (rx != 0f) tm.rotate(Vector3.X, rx)
        p.setVertexTransform(tm); p.box(sx, sy, sz); p.setVertexTransform(null)
    }

    private fun sph(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
        tm.idt().translate(cx, cy, cz)
        p.setVertexTransform(tm); p.sphere(sx, sy, sz, 10, 8); p.setVertexTransform(null)
    }

    /** Cylinder whose axis runs along X (wheel-like). */
    private fun cylX(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, dia: Float, width: Float) {
        tm.idt().translate(cx, cy, cz).rotate(Vector3.Z, 90f)
        p.setVertexTransform(tm); p.cylinder(dia, width, dia, 18); p.setVertexTransform(null)
    }

    private fun vi(v: MeshPartBuilder.VertexInfo, x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
        v.set(t1.set(x, y, z), t2.set(nx, ny, nz), null, null)
    }

    // ------------------------------------------------------------ lofting
    private fun cr(p0: Float, p1: Float, p2: Float, p3: Float, t: Float): Float =
        0.5f * ((2f * p1) + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t * t + (-p0 + 3f * p1 - 3f * p2 + p3) * t * t * t)

    private fun subdivide(s: List<Sec>, k: Int): List<Sec> {
        val out = ArrayList<Sec>()
        val n = s.size
        for (i in 0 until n - 1) {
            val a = s[max(0, i - 1)]; val b = s[i]; val c = s[i + 1]; val d = s[min(n - 1, i + 2)]
            for (j in 0 until k) {
                val t = j / k.toFloat()
                val z = b.z + (c.z - b.z) * t
                out.add(Sec(z, max(0.02f, cr(a.hw, b.hw, c.hw, d.hw, t)), cr(a.yb, b.yb, c.yb, d.yb, t), cr(a.yt, b.yt, c.yt, d.yt, t)))
            }
        }
        out.add(s[n - 1])
        return out
    }

    private fun loft(p: MeshPartBuilder, key: List<Sec>, n: Int, pw: Float, sub: Int) {
        val s = subdivide(key, sub)
        val m = s.size
        val px = Array(m) { FloatArray(n) }
        val py = Array(m) { FloatArray(n) }
        for (i in 0 until m) {
            val c = s[i]
            val cy = (c.yb + c.yt) * 0.5f
            val hh = max(0.004f, (c.yt - c.yb) * 0.5f)
            for (j in 0 until n) {
                val a = j * MathUtils.PI2 / n
                val co = MathUtils.cos(a); val si = MathUtils.sin(a)
                px[i][j] = c.hw * sgn(co) * abs(co).pow(2f / pw)
                py[i][j] = cy + hh * sgn(si) * abs(si).pow(2f / pw)
            }
        }
        val nx = Array(m) { FloatArray(n) }
        val ny = Array(m) { FloatArray(n) }
        val nz = Array(m) { FloatArray(n) }
        for (i in 0 until m) for (j in 0 until n) {
            val i0 = max(0, i - 1); val i1 = min(m - 1, i + 1)
            val j0 = (j + n - 1) % n; val j1 = (j + 1) % n
            val ax = px[i1][j] - px[i0][j]; val ay = py[i1][j] - py[i0][j]; val az = s[i1].z - s[i0].z
            val bx = px[i][j1] - px[i][j0]; val by = py[i][j1] - py[i][j0]
            var cx = ay * 0f - az * by
            var cy = az * bx - ax * 0f
            var cz = ax * by - ay * bx
            val l = sqrt(cx * cx + cy * cy + cz * cz)
            if (l < 1e-6f) { cx = 0f; cy = 1f; cz = 0f } else { cx /= l; cy /= l; cz /= l }
            nx[i][j] = cx; ny[i][j] = cy; nz[i][j] = cz
        }
        // make every normal point outwards (sample the right-hand side at mid length)
        val flip = if (nx[m / 2][0] < 0f) -1f else 1f
        for (i in 0 until m) for (j in 0 until n) { nx[i][j] *= flip; ny[i][j] *= flip; nz[i][j] *= flip }

        for (i in 0 until m - 1) for (j in 0 until n) {
            val j1 = (j + 1) % n
            vi(ia, px[i][j], py[i][j], s[i].z, nx[i][j], ny[i][j], nz[i][j])
            vi(ib, px[i][j1], py[i][j1], s[i].z, nx[i][j1], ny[i][j1], nz[i][j1])
            vi(ic, px[i + 1][j1], py[i + 1][j1], s[i + 1].z, nx[i + 1][j1], ny[i + 1][j1], nz[i + 1][j1])
            vi(id, px[i + 1][j], py[i + 1][j], s[i + 1].z, nx[i + 1][j], ny[i + 1][j], nz[i + 1][j])
            p.rect(ia, ib, ic, id)
        }
        // end caps
        for (end in 0..1) {
            val i = if (end == 0) 0 else m - 1
            val dir = if (end == 0) 1f else -1f
            val cy = (s[i].yb + s[i].yt) * 0.5f
            for (j in 0 until n) {
                val j1 = (j + 1) % n
                vi(ia, 0f, cy, s[i].z, 0f, 0f, dir)
                vi(ib, px[i][j], py[i][j], s[i].z, 0f, 0f, dir)
                vi(ic, px[i][j1], py[i][j1], s[i].z, 0f, 0f, dir)
                p.triangle(ia, ib, ic)
            }
        }
    }

    private fun bodySecs(tab: Array<FloatArray>, L: Float, W: Float, c: Float, bh: Float): List<Sec> =
        tab.map { Sec(it[0] * L, it[1] * W * 0.5f, c + it[2] * bh, c + it[3] * bh) }

    private fun cabSecs(tab: Array<FloatArray>, L: Float, W: Float, yBase: Float, ch: Float): List<Sec> =
        tab.map { Sec(it[0] * L, it[1] * W * 0.5f, yBase, yBase + max(0.03f, it[2] * ch)) }

    private fun roofSecs(cab: List<Sec>): List<Sec> =
        cab.map { Sec(it.z, it.hw * 1.012f, max(it.yb, it.yt - 0.06f), it.yt) }

    // ------------------------------------------------------------ the car
    fun build(spec: CarSpec, bodyColor: Color): CarModel {
        val model = if (spec.kind == 3) buildAuto(spec, bodyColor) else buildCar(spec, bodyColor)
        Gfx.track(model)
        return CarModel(model, wheelFor(spec))
    }

    private fun wheelFor(spec: CarSpec): Model = Gfx.wheelModel(spec.wheelR)

    private fun buildCar(spec: CarSpec, bodyColor: Color): Model {
        val L = spec.len; val W = spec.wid; val c = spec.clearance; val bh = spec.bodyH; val ch = spec.cabinH
        val kind = spec.kind
        val bodyTab = when (kind) { 1 -> SUV_BODY; 2 -> SUPER_BODY; else -> SEDAN_BODY }
        val cabTab = when (kind) { 1 -> SUV_CAB; 2 -> SUPER_CAB; else -> SEDAN_CAB }
        val yBase = c + bh * 0.90f
        val cab = cabSecs(cabTab, L, W, yBase, ch)
        val bdr = ModelBuilder()
        bdr.begin()

        var p = bdr.part("paint", GL20.GL_TRIANGLES, Gfx.A, paint(bodyColor))
        loft(p, bodySecs(bodyTab, L, W, c, bh), 16, 3.4f, 3)
        loft(p, roofSecs(cab), 14, 3.0f, 3)
        for (sx in floatArrayOf(-1f, 1f)) box(p, sx * (W * 0.47f + 0.07f), yBase + 0.10f, L * 0.12f, 0.14f, 0.10f, 0.20f)   // mirrors
        if (kind == 2) {                                                                                              // spoiler
            box(p, 0f, c + bh * 0.9f + 0.30f, -L * 0.46f, W * 0.92f, 0.035f, 0.30f)
            for (sx in floatArrayOf(-1f, 1f)) box(p, sx * W * 0.30f, c + bh * 0.9f + 0.15f, -L * 0.46f, 0.05f, 0.30f, 0.08f)
        }

        p = bdr.part("glass", GL20.GL_TRIANGLES, Gfx.A, glassMat())
        loft(p, cab, 14, 3.0f, 3)

        p = bdr.part("trim", GL20.GL_TRIANGLES, Gfx.A, dull(0.05f, 0.05f, 0.06f, 0.3f, 12f))
        box(p, 0f, c + bh * 0.42f, L * 0.49f, W * 0.48f, bh * 0.20f, 0.06f)                  // grille
        box(p, 0f, c + bh * 0.07f, L * 0.49f, W * 0.72f, bh * 0.10f, 0.10f)                  // splitter
        box(p, 0f, c + bh * 0.12f, -L * 0.495f, W * 0.80f, bh * 0.16f, 0.08f)                // rear valance
        for (sx in floatArrayOf(-1f, 1f)) for (sz in floatArrayOf(-1f, 1f))                  // wheel arches
            cylX(p, sx * (W * 0.5f + 0.005f), spec.wheelR, sz * spec.wheelBase * 0.5f, spec.wheelR * 2f + 0.14f, 0.02f)

        p = bdr.part("chrome", GL20.GL_TRIANGLES, Gfx.A, chromeMat())
        box(p, 0f, c + bh * 0.22f, L * 0.50f, W * 0.66f, 0.05f, 0.05f)
        box(p, 0f, c + bh * 0.30f, -L * 0.50f, 0.50f, 0.12f, 0.03f)                          // plates
        box(p, 0f, c + bh * 0.22f, L * 0.50f + 0.02f, 0.50f, 0.12f, 0.02f)

        p = bdr.part("head", GL20.GL_TRIANGLES, Gfx.A, lightMat(1f, 0.97f, 0.8f, 0.9f, 0.85f, 0.6f))
        for (sx in floatArrayOf(-1f, 1f)) sph(p, sx * W * 0.32f, c + bh * 0.62f, L * 0.49f, 0.34f, 0.16f, 0.14f)

        p = bdr.part("tail", GL20.GL_TRIANGLES, Gfx.A, lightMat(0.7f, 0.05f, 0.05f, 0.65f, 0.02f, 0.02f))
        for (sx in floatArrayOf(-1f, 1f)) box(p, sx * W * 0.34f, c + bh * 0.66f, -L * 0.50f, 0.30f, 0.12f, 0.05f)

        return bdr.end()
    }

    private fun buildAuto(spec: CarSpec, bodyColor: Color): Model {
        val L = spec.len; val W = spec.wid; val c = spec.clearance; val bh = spec.bodyH; val ch = spec.cabinH
        val topY = c + bh
        val bdr = ModelBuilder()
        bdr.begin()

        var p = bdr.part("paint", GL20.GL_TRIANGLES, Gfx.A, paint(bodyColor))
        loft(p, bodySecs(AUTO_BODY, L, W, c, bh), 14, 3.2f, 3)
        box(p, 0f, 0.62f, L * 0.30f, 0.30f, 0.05f, 0.7f)                                     // front mudguard

        p = bdr.part("roof", GL20.GL_TRIANGLES, Gfx.A, paint(spec.cabin))
        box(p, 0f, topY + ch, -L * 0.12f, W * 0.98f, 0.07f, L * 0.64f)

        p = bdr.part("glass", GL20.GL_TRIANGLES, Gfx.A, glassMat())
        box(p, 0f, topY + ch * 0.45f, L * 0.19f, W * 0.92f, ch * 0.75f, 0.025f, -12f)

        p = bdr.part("trim", GL20.GL_TRIANGLES, Gfx.A, dull(0.06f, 0.06f, 0.07f, 0.3f, 12f))
        for (sx in floatArrayOf(-1f, 1f)) {
            box(p, sx * W * 0.47f, topY + ch * 0.5f, L * 0.17f, 0.05f, ch, 0.05f)
            box(p, sx * W * 0.47f, topY + ch * 0.5f, -L * 0.42f, 0.05f, ch, 0.05f)
        }
        box(p, 0f, topY * 0.72f + c * 0.3f + 0.2f, -L * 0.28f, W * 0.80f, 0.26f, L * 0.30f)  // seat
        box(p, 0f, topY + 0.2f, -L * 0.45f, W * 0.80f, 0.45f, 0.10f)                         // back rest
        box(p, 0f, topY + 0.18f, L * 0.20f, 0.70f, 0.04f, 0.04f)                             // handlebar

        p = bdr.part("head", GL20.GL_TRIANGLES, Gfx.A, lightMat(1f, 0.97f, 0.8f, 0.9f, 0.85f, 0.6f))
        sph(p, 0f, c + bh * 0.72f, L * 0.49f, 0.30f, 0.26f, 0.16f)

        p = bdr.part("tail", GL20.GL_TRIANGLES, Gfx.A, lightMat(0.7f, 0.05f, 0.05f, 0.65f, 0.02f, 0.02f))
        for (sx in floatArrayOf(-1f, 1f)) box(p, sx * W * 0.38f, c + bh * 0.5f, -L * 0.50f, 0.18f, 0.10f, 0.04f)

        return bdr.end()
    }

    // ------------------------------------------------------------ wheel (axis = X, rolls about X)
    fun wheel(r: Float): Model {
        val w = 0.26f
        val bdr = ModelBuilder()
        bdr.begin()
        var p = bdr.part("tire", GL20.GL_TRIANGLES, Gfx.A, dull(0.06f, 0.06f, 0.06f, 0.12f, 6f))
        cylX(p, 0f, 0f, 0f, r * 2f, w)
        p = bdr.part("well", GL20.GL_TRIANGLES, Gfx.A, dull(0.10f, 0.10f, 0.11f, 0.3f, 10f))
        cylX(p, 0f, 0f, 0f, r * 2f * 0.64f, w + 0.01f)
        p = bdr.part("spokes", GL20.GL_TRIANGLES, Gfx.A, chromeMat())
        for (k in 0 until 5) {
            tm.idt().rotate(Vector3.X, k * 36f)
            p.setVertexTransform(tm); p.box(w + 0.03f, r * 2f * 0.62f, 0.05f); p.setVertexTransform(null)
        }
        cylX(p, 0f, 0f, 0f, r * 0.45f, w + 0.045f)
        return bdr.end()
    }
}
