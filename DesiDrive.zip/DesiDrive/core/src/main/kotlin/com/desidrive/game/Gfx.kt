package com.desidrive.game

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.Vector3

object Gfx {
    private val mb = ModelBuilder()
    private val all = ArrayList<Model>()
    private val boxes = HashMap<Int, Model>()
    private val cyls = HashMap<Int, Model>()
    private val spheres = HashMap<Int, Model>()
    private val A: Long = (Usage.Position or Usage.Normal).toLong()
    private val AT: Long = (Usage.Position or Usage.Normal or Usage.TextureCoordinates).toLong()
    private var facade: Texture? = null

    private fun mat(c: Color) = Material(ColorAttribute.createDiffuse(c))

    /** Procedural window/facade texture (white wall + windows). Tinted per building. */
    fun makeFacade() {
        val pm = Pixmap(64, 64, Pixmap.Format.RGBA8888)
        pm.setColor(1f, 1f, 1f, 1f); pm.fill()
        pm.setColor(0.85f, 0.85f, 0.85f, 1f); pm.fillRectangle(0, 56, 64, 8)       // floor band
        pm.setColor(0.17f, 0.24f, 0.34f, 1f); pm.fillRectangle(16, 10, 32, 32)       // window
        pm.setColor(0.72f, 0.84f, 0.95f, 1f); pm.fillRectangle(19, 13, 26, 10)       // glass shine
        pm.setColor(0.92f, 0.92f, 0.92f, 1f); pm.fillRectangle(12, 44, 40, 4)        // sill
        pm.setColor(0.55f, 0.55f, 0.55f, 1f); pm.fillRectangle(31, 10, 2, 32)        // frame
        val t = Texture(pm, true)
        t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear)
        t.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat)
        pm.dispose()
        facade = t
    }

    fun box(c: Color): ModelInstance {
        val m = boxes.getOrPut(c.toIntBits()) {
            val x = mb.createBox(1f, 1f, 1f, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    fun cyl(c: Color): ModelInstance {
        val m = cyls.getOrPut(c.toIntBits()) {
            val x = mb.createCylinder(1f, 1f, 1f, 14, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    fun sphere(c: Color): ModelInstance {
        val m = spheres.getOrPut(c.toIntBits()) {
            val x = mb.createSphere(1f, 1f, 1f, 12, 10, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    /** Textured building (windows tile with size). */
    fun building(w: Float, h: Float, d: Float, c: Color): ModelInstance {
        val ta = TextureAttribute.createDiffuse(facade!!)
        ta.scaleU = w / 5f
        ta.scaleV = h / 4f
        val m = mb.createBox(w, h, d, Material(ColorAttribute.createDiffuse(c), ta), AT)
        all.add(m)
        return ModelInstance(m)
    }

    /** Translucent mission beam. */
    fun beam(c: Color, alpha: Float): ModelInstance {
        val m = mb.createCylinder(
            1f, 1f, 1f, 18,
            Material(ColorAttribute.createDiffuse(c), BlendingAttribute(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA, alpha)),
            A
        )
        all.add(m)
        return ModelInstance(m)
    }

    /** World position + yaw, then local offset, optional roll(Z), then scale. */
    fun put(
        i: ModelInstance, x: Float, y: Float, z: Float, yaw: Float,
        lx: Float, ly: Float, lz: Float,
        sx: Float, sy: Float, sz: Float, roll: Float = 0f
    ) {
        i.transform.idt().translate(x, y, z).rotate(Vector3.Y, yaw).translate(lx, ly, lz)
        if (roll != 0f) i.transform.rotate(Vector3.Z, roll)
        i.transform.scale(sx, sy, sz)
    }

    fun dispose() {
        for (m in all) m.dispose()
        facade?.dispose()
    }
}
