package com.desidrive.game

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.Environment
import com.badlogic.gdx.graphics.g3d.ModelBatch
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalShadowLight
import com.badlogic.gdx.graphics.g3d.utils.DepthShaderProvider
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.tan

enum class Quality(val label: String, val drawDist: Float, val npcDist: Float, val shadows: Boolean) {
    LOW("LOW", 80f, 45f, false),
    MEDIUM("MEDIUM", 140f, 85f, true),
    HIGH("HIGH", 210f, 140f, true)
}

class Mission(
    val title: String, val x: Float, val z: Float, val goons: Int, val boss: Boolean,
    val intro: List<String>, val outro: List<String>
)

private class Txt(val s: String, val x: Float, val y: Float, val sc: Float, val col: Color, val center: Boolean)
private class Ptr { var role = 0; var lx = 0f; var ly = 0f }

class DesiGame : ApplicationAdapter() {
    private lateinit var cam: PerspectiveCamera
    private lateinit var uiCam: OrthographicCamera
    private lateinit var modelBatch: ModelBatch
    private lateinit var shadowBatch: ModelBatch
    private lateinit var env: Environment
    private lateinit var shadowLight: DirectionalShadowLight
    private lateinit var shape: ShapeRenderer
    private lateinit var sb: SpriteBatch
    private lateinit var font: BitmapFont
    private lateinit var world: World
    private lateinit var hero: Human
    private lateinit var beam: ModelInstance
    private var logo: Texture? = null
    private val glyph = GlyphLayout()
    private val sky = Color(0.62f, 0.78f, 0.92f, 1f)

    private var W = 1280f; private var H = 720f; private var u = 1f
    private var started = false
    private var quality = Quality.HIGH
    private var settingsOpen = false
    private var mapOpen = false
    private var time = 0f

    // entities
    private val heroType = NpcType("Major Arjun", "4b5320", "3b4a1c", "c68642", "2f3a14", Beh.WALK)
    private val goonType = NpcType("Kabira ka goon", "1e272e", "485460", "8d5524", "eb4d4b", Beh.WALK)
    private val kabiraType = NpcType("Kabira", "8e1b1b", "1e1e1e", "8d5524", "000000", Beh.WALK, 1.15f)
    private var car: Car? = null
    private val cars = ArrayList<Car>()
    private val npcs = ArrayList<Human>()
    private val goons = ArrayList<Human>()
    private var hp = 100f; private var hurtT = 0f; private var fireCd = 0f; private var hitFlash = 0f

    // input
    private val ptrs = Array(5) { Ptr() }
    private var jx = 0f; private var jy = 0f
    private var gasB = false; private var brakeB = false; private var fireB = false; private var runB = false
    private var lookActive = false
    private var joyActive = false
    private var joyCx = 0f; private var joyCy = 0f; private var joyKx = 0f; private var joyKy = 0f
    private var joyR = 100f

    // camera
    private var camYaw = 0f
    private var camPitch = 18f

    // missions
    private val missions = listOf(
        Mission("Mission 1: Pehla Suraag", -40f, -95f, 0, false,
            listOf("Major Arjun: Kabira ne Riya ko kidnap kar liya! Main use chhodunga nahi.", "Mandir ke paas chai tapri par jao - chaiwale ko kuch pata hai."),
            listOf("Chaiwala: Saab, Kabira ke aadmi purane godown me dikhe the.", "Godown ki taraf nikalo! (MAP dekho)")),
        Mission("Mission 2: Adda #1 - Godown", -40f, 28f, 3, false,
            listOf("Godown me Kabira ke 3 goon hain. FIRE dabake saaf karo!"),
            listOf("Godown clear! Ek parchi mili: 'Highway dhaba'.")),
        Mission("Mission 3: Adda #2 - Highway Dhaba", 120f, -42f, 4, false,
            listOf("Dhaba door hai - CAR button se gaadi lo aur tez jao!"),
            listOf("Dhaba clear! Naksha mila: Puraani factory.")),
        Mission("Mission 4: Adda #3 - Puraani Factory", 40f, 108f, 5, false,
            listOf("Factory me 5 goon hain. Savdhaan Major!"),
            listOf("Factory clear! Kabira ka asli thikana mil gaya.")),
        Mission("Mission 5: Kabira ka Adda", 120f, 106f, 3, true,
            listOf("Yahi hai Kabira ka adda. Riya andar hai!"),
            listOf("Kabira dhher! Riya: Arjun! Tum aa gaye!", "MISSION COMPLETE - Jai Hind!"))
    )
    private var mIdx = 0
    private var phase = 0 // 0 goto, 1 fight, 2 all done
    private val msgs = ArrayList<String>()

    private val vis = ArrayList<ModelInstance>()
    private val casters = ArrayList<ModelInstance>()
    private val texts = ArrayList<Txt>()
    private val p2 = FloatArray(2)
    private val ctr = Vector3()

    override fun create() {
        W = Gdx.graphics.width.toFloat(); H = Gdx.graphics.height.toFloat(); u = H / 720f
        Gfx.makeFacade()
        world = World()
        cam = PerspectiveCamera(65f, W, H)
        cam.near = 0.3f; cam.far = 250f
        uiCam = OrthographicCamera()
        uiCam.setToOrtho(false, W, H)
        modelBatch = ModelBatch()
        shadowBatch = ModelBatch(DepthShaderProvider())
        env = Environment()
        env.set(ColorAttribute(ColorAttribute.AmbientLight, 0.5f, 0.5f, 0.55f, 1f))
        env.set(ColorAttribute(ColorAttribute.Fog, sky.r, sky.g, sky.b, 1f))
        shadowLight = DirectionalShadowLight(2048, 2048, 90f, 90f, 1f, 260f)
        shadowLight.set(1f, 0.95f, 0.85f, -0.6f, -0.8f, -0.4f)
        env.add(shadowLight)
        applyQuality(Quality.HIGH)
        shape = ShapeRenderer()
        sb = SpriteBatch()
        font = BitmapFont()
        font.region.texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        try {
            val t = Texture(Gdx.files.internal("logo.png"), true)
            t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear)
            logo = t
        } catch (e: Exception) { logo = null }

        hero = Human(heroType)
        hero.x = -120f; hero.z = -115f; hero.yaw = 0f

        // cars
        cars.add(Car(CarSpecs.SEDAN, -140f, -102f, 0f))
        cars.add(Car(CarSpecs.SUV, -125f, -102f, 0f))
        cars.add(Car(CarSpecs.SUPER, -110f, -102f, 0f))
        cars.add(Car(CarSpecs.AUTO, -97f, -102f, 0f))
        cars.add(Car(CarSpecs.SUV, 3f, -40f, 0f, Color.valueOf("1c1c1c")))
        cars.add(Car(CarSpecs.AUTO, -77f, 20f, 0f))
        cars.add(Car(CarSpecs.SUPER, 83f, 60f, 180f, Color.valueOf("f1c40f")))
        cars.add(Car(CarSpecs.SEDAN, -157f, 100f, 0f, Color.valueOf("b2bec3")))
        cars.add(Car(CarSpecs.AUTO, 40f, 3f, 90f))
        cars.add(Car(CarSpecs.SUV, 105f, 120f, 90f, Color.valueOf("111111")))

        spawnNpcs()
        beam = Gfx.beam(Color(1f, 0.85f, 0.1f, 1f), 0.35f)
        queueIntro()
    }

    private fun applyQuality(q: Quality) {
        quality = q
        env.shadowMap = if (q.shadows) shadowLight else null
    }

    private fun spawnNpcs() {
        val rnd = java.util.Random(11)
        // scripted chaiwala next to the stall
        val chai = Human(NPC_TYPES[0]); chai.x = -35.5f; chai.z = -96f; chai.yaw = 120f; npcs.add(chai)
        for (t in NPC_TYPES) {
            val walker = t.beh == Beh.WALK || t.beh == Beh.JOG
            val cnt = if (walker) 3 else 2
            repeat(cnt) {
                val h = Human(t)
                val ri = rnd.nextInt(world.roads.size)
                val side = if (rnd.nextBoolean()) 7.5f else -7.5f
                val line = world.roads[ri] + side
                val ax = rnd.nextBoolean()
                if (walker) {
                    h.axisX = ax; h.fixed = line
                    h.lo = -200f + rnd.nextFloat() * 150f
                    h.hi = h.lo + 60f + rnd.nextFloat() * 80f
                    h.t = h.lo + rnd.nextFloat() * (h.hi - h.lo)
                    h.dir = if (rnd.nextBoolean()) 1f else -1f
                } else {
                    var s = 0f
                    var ok = false
                    while (!ok) {
                        s = -190f + rnd.nextFloat() * 380f
                        ok = world.roads.none { abs(s - it) < 12f }
                    }
                    if (ax) { h.x = s; h.z = line; h.yaw = if (side > 0) 180f else 0f }
                    else { h.x = line; h.z = s; h.yaw = if (side > 0) -90f else 90f }
                }
                npcs.add(h)
            }
        }
    }

    private fun say(s: String) { msgs.add(s) }
    private fun queueIntro() { for (s in missions[mIdx].intro) say(s) }

    // ------------------------------------------------------------ update
    override fun render() {
        val dt = min(Gdx.graphics.deltaTime, 1f / 20f)
        if (!started) { drawMenu(); return }
        time += dt
        update(dt)
        render3D()
        drawHud()
    }

    private fun update(dt: Float) {
        readInput()
        val c = car
        if (c != null) { driveCar(c, dt); hero.x = c.x; hero.z = c.z }
        else walkHero(dt)
        updateNpcs(dt)
        updateGoons(dt)
        updateMission()
        if (hurtT > 0f) hurtT -= dt else if (hp < 100f) hp = min(100f, hp + 3f * dt)
        if (hitFlash > 0f) hitFlash -= dt
        if (hp <= 0f) respawn()
        tickMessages(dt)
        updateCamera(dt)
    }

    private var shownMsg = ""
    private var shownT = 0f
    private fun tickMessages(dt: Float) {
        if (shownT > 0f) { shownT -= dt; return }
        if (msgs.isNotEmpty()) { shownMsg = msgs.removeAt(0); shownT = 4.2f } else shownMsg = ""
    }

    private fun readInput() {
        jx = 0f; jy = 0f; gasB = false; brakeB = false; fireB = false; runB = false
        lookActive = false; joyActive = false
        joyR = 100f * u
        for (i in 0 until 5) {
            val p = ptrs[i]
            if (!Gdx.input.isTouched(i)) { p.role = 0; continue }
            val x = Gdx.input.getX(i).toFloat()
            val y = H - Gdx.input.getY(i).toFloat()
            if (p.role == 0) {
                p.role = classify(x, y); p.lx = x; p.ly = y
                when (p.role) {
                    1 -> { joyCx = x; joyCy = y }
                    5 -> toggleCar()
                    6 -> mapOpen = !mapOpen
                    7 -> settingsOpen = true
                    8 -> settingsClick(x, y)
                }
            }
            when (p.role) {
                1 -> {
                    var dx = (x - joyCx) / joyR; var dy = (y - joyCy) / joyR
                    val l = hypot(dx, dy)
                    if (l > 1f) { dx /= l; dy /= l }
                    jx = dx; jy = dy; joyActive = true
                    joyKx = joyCx + dx * joyR; joyKy = joyCy + dy * joyR
                }
                2 -> {
                    camYaw -= (x - p.lx) * 0.22f
                    camPitch = (camPitch + (y - p.ly) * 0.12f).coerceIn(6f, 55f)
                    p.lx = x; p.ly = y; lookActive = true
                }
                3 -> if (car != null) gasB = true else fireB = true
                4 -> if (car != null) brakeB = true else runB = true
            }
        }
    }

    private fun d(x1: Float, y1: Float, x2: Float, y2: Float) = hypot(x1 - x2, y1 - y2)

    private fun classify(x: Float, y: Float): Int {
        if (settingsOpen) return 8
        if (mapOpen) return 6
        if (d(x, y, W - 60f * u, H - 55f * u) < 42f * u) return 6
        if (d(x, y, W - 150f * u, H - 55f * u) < 42f * u) return 7
        if (d(x, y, W - 120f * u, 330f * u) < 58f * u) return 5
        if (d(x, y, W - 120f * u, 150f * u) < 74f * u) return 3
        if (d(x, y, W - 270f * u, 110f * u) < 58f * u) return 4
        if (x < W * 0.45f && y < H * 0.78f) return 1
        if (x >= W * 0.45f) return 2
        return 9
    }

    private fun nearestCar(): Car? {
        var best: Car? = null; var bd = 4.8f
        for (c in cars) {
            val dd = hypot(c.x - hero.x, c.z - hero.z)
            if (dd < bd) { bd = dd; best = c }
        }
        return best
    }

    private fun toggleCar() {
        val c = car
        if (c != null) {
            if (abs(c.speed) > 8f) { say("Pehle gaadi roko!"); return }
            c.speed = 0f
            val yr = c.yaw * MathUtils.degreesToRadians
            hero.x = c.x + cos(yr) * (c.spec.wid * 0.5f + 1.1f)
            hero.z = c.z - sin(yr) * (c.spec.wid * 0.5f + 1.1f)
            hero.yaw = c.yaw
            car = null
            collideHero()
        } else {
            val n = nearestCar()
            if (n != null) { car = n; n.speed = 0f; hero.moving = false }
        }
    }

    private fun collideHero() {
        p2[0] = hero.x; p2[1] = hero.z
        repeat(2) {
            world.resolve(p2, 0.45f)
            for (c in cars) {
                val yr = c.yaw * MathUtils.degreesToRadians
                for (s in floatArrayOf(-1f, 1f)) {
                    val cx = c.x + sin(yr) * c.spec.len * 0.27f * s
                    val cz = c.z + cos(yr) * c.spec.len * 0.27f * s
                    val dx = p2[0] - cx; val dz = p2[1] - cz
                    val dd = hypot(dx, dz)
                    val md = c.spec.wid * 0.58f + 0.45f
                    if (dd < md && dd > 0.001f) { p2[0] = cx + dx / dd * md; p2[1] = cz + dz / dd * md }
                }
            }
        }
        hero.x = p2[0]; hero.z = p2[1]
    }

    private fun walkHero(dt: Float) {
        val yr = camYaw * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        val mx = fx * jy + (-fz) * jx
        val mz = fz * jy + fx * jx
        val len = hypot(mx, mz)
        if (len > 0.12f) {
            val sp = if (runB) 7.5f else if (len > 0.85f) 4.8f else 2.4f
            val nx = mx / len; val nz = mz / len
            hero.x += nx * sp * dt; hero.z += nz * sp * dt
            hero.yaw = MathUtils.lerpAngleDeg(hero.yaw, atan2(nx, nz) * MathUtils.radiansToDegrees, min(1f, dt * 12f))
            hero.anim += sp * dt * 1.8f
            hero.moving = true
        } else hero.moving = false
        collideHero()

        // shooting: auto-aim nearest goon
        fireCd -= dt
        if (fireB && fireCd <= 0f) {
            var tgt: Human? = null; var bd = 40f
            for (g in goons) if (g.alive) {
                val dd = hypot(g.x - hero.x, g.z - hero.z)
                if (dd < bd) { bd = dd; tgt = g }
            }
            fireCd = 0.28f
            if (tgt != null) {
                hero.yaw = atan2(tgt.x - hero.x, tgt.z - hero.z) * MathUtils.radiansToDegrees
                tgt.hp -= 14f; hitFlash = 0.12f
                if (tgt.hp <= 0f) { tgt.alive = false; say(if (tgt.isBoss) "Kabira gir gaya!" else "Goon dhher!") }
            }
        }
    }

    private fun driveCar(c: Car, dt: Float) {
        val sp = c.spec
        val thr = if (gasB) 1f else if (brakeB) -1f else jy
        var acc = 0f
        if (thr > 0.05f) {
            acc = if (c.speed < -0.5f) sp.brake else sp.accel * thr * (1f - (c.speed / sp.maxSpeed).coerceIn(0f, 1f))
        } else if (thr < -0.05f) {
            acc = if (c.speed > 0.5f) -sp.brake * (-thr)
            else sp.accel * 0.5f * thr * (1f - (-c.speed / (sp.maxSpeed * 0.25f)).coerceIn(0f, 1f))
        }
        c.speed += acc * dt
        c.speed -= c.speed * 0.25f * dt
        if (abs(thr) < 0.05f) c.speed -= sign(c.speed) * min(abs(c.speed), 3f * dt)
        c.speed = c.speed.coerceIn(-sp.maxSpeed * 0.25f, sp.maxSpeed)

        val maxSteer = 0.55f * (1f - min(1f, abs(c.speed) / sp.maxSpeed) * 0.7f)
        val yawRate = c.speed / sp.wheelBase * tan(jx * maxSteer)
        c.yaw -= yawRate * MathUtils.radiansToDegrees * dt
        val yr = c.yaw * MathUtils.degreesToRadians
        c.x += sin(yr) * c.speed * dt
        c.z += cos(yr) * c.speed * dt
        if (collideCar(c)) c.speed *= max(0f, 1f - 3f * dt)
        if (!lookActive && abs(c.speed) > 1f) camYaw = MathUtils.lerpAngleDeg(camYaw, c.yaw, min(1f, dt * 2.2f))
    }

    private fun collideCar(c: Car): Boolean {
        var hit = false
        repeat(3) {
            val yr = c.yaw * MathUtils.degreesToRadians
            val sx = sin(yr); val sz = cos(yr)
            val off = c.spec.len * 0.27f
            val r = c.spec.wid * 0.58f
            for (s in floatArrayOf(-1f, 1f)) {
                p2[0] = c.x + sx * off * s; p2[1] = c.z + sz * off * s
                val ox = p2[0]; val oz = p2[1]
                if (world.resolve(p2, r)) { hit = true; c.x += p2[0] - ox; c.z += p2[1] - oz }
            }
            for (o in cars) {
                if (o === c) continue
                val dx = c.x - o.x; val dz = c.z - o.z
                val dd = hypot(dx, dz)
                val md = (c.spec.len + o.spec.len) * 0.36f
                if (dd < md && dd > 0.001f) { c.x += dx / dd * (md - dd); c.z += dz / dd * (md - dd); hit = true }
            }
        }
        return hit
    }

    private fun updateNpcs(dt: Float) {
        for (n in npcs) {
            if (n.type.beh == Beh.STAND || n.type.beh == Beh.PHONE) { n.moving = false; continue }
            val sp = n.type.speed * (if (n.type.beh == Beh.JOG) 2.2f else 1f)
            n.t += n.dir * sp * dt
            if (n.t > n.hi) { n.t = n.hi; n.dir = -1f } else if (n.t < n.lo) { n.t = n.lo; n.dir = 1f }
            if (n.axisX) { n.x = n.t; n.z = n.fixed; n.yaw = if (n.dir > 0) 90f else -90f }
            else { n.z = n.t; n.x = n.fixed; n.yaw = if (n.dir > 0) 0f else 180f }
            n.anim += sp * dt * 2.4f
            n.moving = true
        }
    }

    private fun updateGoons(dt: Float) {
        for (g in goons) {
            if (!g.alive) continue
            val dx = hero.x - g.x; val dz = hero.z - g.z
            val dd = hypot(dx, dz)
            if (dd < 45f) {
                g.yaw = MathUtils.lerpAngleDeg(g.yaw, atan2(dx, dz) * MathUtils.radiansToDegrees, min(1f, dt * 8f))
                if (dd > 11f) {
                    val sp = if (g.isBoss) 3.6f else 3.2f
                    g.x += dx / dd * sp * dt; g.z += dz / dd * sp * dt
                    g.anim += sp * dt * 2f; g.moving = true
                } else g.moving = false
                if (dd < 24f) {
                    hp -= (if (g.isBoss) 7f else 4f) * (if (car != null) 0.5f else 1f) * dt
                    hurtT = 0.3f
                }
            } else g.moving = false
            p2[0] = g.x; p2[1] = g.z
            world.resolve(p2, 0.45f)
            g.x = p2[0]; g.z = p2[1]
        }
        goons.removeAll { !it.alive }
    }

    private fun updateMission() {
        val m = missions.getOrNull(mIdx) ?: return
        if (phase == 0) {
            if (hypot(hero.x - m.x, hero.z - m.z) < 7f) {
                if (m.goons == 0 && !m.boss) completeMission(m)
                else { spawnGoons(m); phase = 1; say("Dushman saamne! FIRE button dabao.") }
            }
        } else if (phase == 1) {
            if (goons.none { it.alive }) completeMission(m)
        }
    }

    private fun spawnGoons(m: Mission) {
        goons.clear()
        for (i in 0 until m.goons) {
            val a = i * (6.2832f / max(1, m.goons)) + 0.5f
            val g = Human(goonType)
            g.x = m.x + cos(a) * 9f; g.z = m.z + sin(a) * 9f
            g.hp = 60f
            goons.add(g)
        }
        if (m.boss) {
            val b = Human(kabiraType)
            b.x = m.x; b.z = m.z + 12f; b.hp = 160f; b.isBoss = true
            goons.add(b)
        }
    }

    private fun completeMission(m: Mission) {
        for (s in m.outro) say(s)
        mIdx++
        if (mIdx >= missions.size) { phase = 2 } else { phase = 0; queueIntro() }
    }

    private fun respawn() {
        hp = 100f
        car = null
        hero.x = -120f; hero.z = -115f; hero.yaw = 0f
        goons.clear()
        if (phase == 1) phase = 0
        msgs.clear(); shownT = 0f
        say("Tum gir gaye... Base par wapas. Dobara koshish karo, Major!")
    }

    // ------------------------------------------------------------ camera
    private fun updateCamera(dt: Float) {
        val tx = hero.x; val tz = hero.z
        val inCar = car != null
        val ty = if (inCar) 1.4f else 1.6f
        val dist = if (inCar) 9.5f else 5.2f
        val pr = camPitch * MathUtils.degreesToRadians
        val yr = camYaw * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        var dd = dist
        var k = 0.6f
        while (k <= dist) {
            val px = tx - fx * k * cos(pr); val pz = tz - fz * k * cos(pr)
            if (world.hit(px, pz, 0.3f)) { dd = max(1.4f, k - 0.8f); break }
            k += 0.6f
        }
        cam.position.set(tx - fx * dd * cos(pr), ty + dd * sin(pr) + 0.4f, tz - fz * dd * cos(pr))
        cam.up.set(0f, 1f, 0f)
        cam.lookAt(tx, ty, tz)
        cam.far = quality.drawDist + 40f
        cam.update()
    }

    // ------------------------------------------------------------ 3D render
    private fun render3D() {
        vis.clear(); casters.clear()
        val tx = hero.x; val tz = hero.z
        val dd = quality.drawDist
        for (p in world.props) {
            val dx = p.x - tx; val dz = p.z - tz; val r = dd + p.r
            if (dx * dx + dz * dz < r * r) { vis.add(p.inst); if (p.caster) casters.add(p.inst) }
        }
        for (c in cars) {
            val dx = c.x - tx; val dz = c.z - tz
            if (dx * dx + dz * dz < dd * dd) { c.layout(); vis.addAll(c.parts); casters.addAll(c.parts) }
        }
        if (car == null) { hero.layout(); vis.addAll(hero.parts); casters.addAll(hero.parts) }
        val nd = quality.npcDist
        for (n in npcs) {
            val dx = n.x - tx; val dz = n.z - tz
            if (dx * dx + dz * dz < nd * nd) { n.layout(); vis.addAll(n.parts); casters.addAll(n.parts) }
        }
        for (g in goons) if (g.alive) { g.layout(); vis.addAll(g.parts); casters.addAll(g.parts) }
        val m = missions.getOrNull(mIdx)
        if (m != null && phase == 0) {
            beam.transform.setToTranslation(m.x, 20f, m.z).scale(3f, 40f, 3f)
            vis.add(beam)
        }

        if (quality.shadows) {
            ctr.set(tx, 0f, tz)
            shadowLight.begin(ctr, cam.direction)
            shadowBatch.begin(shadowLight.camera)
            shadowBatch.render(casters)
            shadowBatch.end()
            shadowLight.end()
        }
        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(sky.r, sky.g, sky.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
        modelBatch.begin(cam)
        modelBatch.render(vis, env)
        modelBatch.end()
    }

    // ------------------------------------------------------------ HUD helpers
    private fun text(s: String, x: Float, y: Float, sc: Float, col: Color = Color.WHITE, center: Boolean = true) {
        texts.add(Txt(s, x, y, sc, col, center))
    }

    private fun flushTexts() {
        sb.begin()
        for (t in texts) {
            font.data.setScale(t.sc * u)
            font.color = t.col
            glyph.setText(font, t.s)
            val tx = if (t.center) t.x - glyph.width / 2f else t.x
            font.draw(sb, t.s, tx, t.y + glyph.height / 2f)
        }
        sb.end()
        texts.clear()
    }

    private fun btn(cx: Float, cy: Float, r: Float, label: String, on: Boolean) {
        shape.setColor(1f, 1f, 1f, if (on) 0.85f else 0.5f)
        shape.circle(cx, cy, r, 36)
        shape.setColor(0.05f, 0.07f, 0.1f, if (on) 0.75f else 0.55f)
        shape.circle(cx, cy, r - 3f * u, 36)
        text(label, cx, cy, 1.3f)
    }

    private fun drawMenu() {
        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(0.05f, 0.08f, 0.15f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        shape.projectionMatrix = uiCam.combined
        sb.projectionMatrix = uiCam.combined
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(1f, 0.6f, 0.2f, 1f); shape.rect(0f, H - 14f * u, W, 14f * u)
        shape.setColor(1f, 1f, 1f, 1f); shape.rect(0f, H - 28f * u, W, 14f * u)
        shape.setColor(0.07f, 0.53f, 0.03f, 1f); shape.rect(0f, H - 42f * u, W, 14f * u)
        shape.end()
        val lg = logo
        if (lg != null) {
            val ls = H * 0.58f
            sb.begin()
            sb.draw(lg, W / 2f - ls / 2f, H * 0.38f, ls, ls)
            sb.end()
        } else {
            text("DESI DRIVER", W / 2f, H * 0.68f, 4.5f, Color(1f, 0.75f, 0.2f, 1f))
        }
        text("Left: move / steer    Right swipe: camera    CAR: gaadi me baitho    FIRE: goli", W / 2f, H * 0.30f, 1.1f, Color.LIGHT_GRAY)
        if ((System.currentTimeMillis() / 500L) % 2L == 0L)
            text("TAP TO START", W / 2f, H * 0.18f, 2.2f)
        flushTexts()
        if (Gdx.input.justTouched()) started = true
    }

    private fun drawHud() {
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        shape.projectionMatrix = uiCam.combined
        sb.projectionMatrix = uiCam.combined
        if (hurtT > 0f) {
            shape.begin(ShapeRenderer.ShapeType.Filled)
            shape.setColor(0.8f, 0f, 0f, min(0.35f, hurtT))
            shape.rect(0f, 0f, W, H)
            shape.end()
        }
        if (mapOpen) { drawFullMap(); return }
        drawMiniMap()
        drawControls()
        drawInfo()
        if (settingsOpen) drawSettings()
    }

    private fun drawControls() {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        val bx = if (joyActive) joyCx else 150f * u
        val by = if (joyActive) joyCy else 150f * u
        shape.setColor(1f, 1f, 1f, 0.16f); shape.circle(bx, by, joyR, 40)
        shape.setColor(1f, 1f, 1f, 0.42f)
        shape.circle(if (joyActive) joyKx else bx, if (joyActive) joyKy else by, 46f * u, 32)
        val inCar = car != null
        btn(W - 120f * u, 150f * u, 70f * u, if (inCar) "GAS" else "FIRE", gasB || fireB)
        btn(W - 270f * u, 110f * u, 55f * u, if (inCar) "BRAKE" else "RUN", brakeB || runB)
        btn(W - 120f * u, 330f * u, 55f * u, if (inCar) "EXIT" else "CAR", inCar || nearestCar() != null)
        btn(W - 60f * u, H - 55f * u, 40f * u, "MAP", false)
        btn(W - 150f * u, H - 55f * u, 40f * u, "SET", false)
        shape.end()
        flushTexts()
    }

    private fun drawInfo() {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        val bw = 280f * u; val bh = 16f * u
        val bx = W / 2f - bw / 2f; val by = H - 34f * u
        shape.setColor(0f, 0f, 0f, 0.5f); shape.rect(bx - 3f * u, by - 3f * u, bw + 6f * u, bh + 6f * u)
        val f = (hp / 100f).coerceIn(0f, 1f)
        shape.setColor(1f - f, f, 0.15f, 0.95f); shape.rect(bx, by, bw * f, bh)
        // mission panel
        val m = missions.getOrNull(mIdx)
        shape.setColor(0f, 0f, 0f, 0.45f)
        shape.rect(W / 2f - 230f * u, H - 112f * u, 460f * u, 62f * u)
        // message banner
        if (shownMsg.isNotEmpty()) {
            shape.setColor(0f, 0f, 0f, 0.6f)
            shape.rect(W / 2f - 330f * u, 20f * u, 660f * u, 56f * u)
        }
        shape.end()
        text("HP", bx - 22f * u, by + bh / 2f, 1.1f)
        if (m != null) {
            text(m.title, W / 2f, H - 68f * u, 1.25f, Color(1f, 0.85f, 0.2f, 1f))
            val dist = hypot(m.x - hero.x, m.z - hero.z).toInt()
            val obj = if (phase == 0) "Marker tak jao: ${dist}m" else "Goons bache: ${goons.count { it.alive }}"
            text(obj, W / 2f, H - 96f * u, 1.1f)
        } else {
            text("Free roam - Jai Hind!", W / 2f, H - 82f * u, 1.3f, Color(0.5f, 1f, 0.5f, 1f))
        }
        if (shownMsg.isNotEmpty()) text(shownMsg, W / 2f, 48f * u, 1.1f)
        val c = car
        if (c != null) {
            text("${(abs(c.speed) * 3.6f).toInt()} km/h", W / 2f, 110f * u, 2f)
            text(c.spec.name, W / 2f, 140f * u, 1f, Color.LIGHT_GRAY)
        }
        if (hitFlash > 0f) text("+", W / 2f, H / 2f, 2.5f, Color.RED)
        flushTexts()
    }

    // minimap: north-up square centered on hero
    private fun drawMiniMap() {
        val s = 170f * u
        val x0 = 16f * u; val y0 = H - s - 16f * u
        val sc = 1.2f * u
        val cx = x0 + s / 2f; val cy = y0 + s / 2f
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(1f, 1f, 1f, 0.8f); shape.rect(x0 - 3f * u, y0 - 3f * u, s + 6f * u, s + 6f * u)
        shape.setColor(0.35f, 0.33f, 0.24f, 1f); shape.rect(x0, y0, s, s)
        shape.end()
        Gdx.gl.glEnable(GL20.GL_SCISSOR_TEST)
        Gdx.gl.glScissor(x0.toInt(), y0.toInt(), s.toInt(), s.toInt())
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0.17f, 0.17f, 0.19f, 1f)
        for (r in world.roads) {
            shape.rect(cx + (r - hero.x) * sc - 6f * sc, y0, 12f * sc, s)
            shape.rect(x0, cy + (r - hero.z) * sc - 6f * sc, s, 12f * sc)
        }
        for (b in world.mapRects) {
            shape.setColor(b.c.r * 0.8f, b.c.g * 0.8f, b.c.b * 0.8f, 1f)
            shape.rect(cx + (b.x0 - hero.x) * sc, cy + (b.z0 - hero.z) * sc, (b.x1 - b.x0) * sc, (b.z1 - b.z0) * sc)
        }
        for (g in goons) if (g.alive) {
            shape.setColor(1f, 0.1f, 0.1f, 1f)
            shape.circle(cx + (g.x - hero.x) * sc, cy + (g.z - hero.z) * sc, 3.5f * u, 10)
        }
        val m = missions.getOrNull(mIdx)
        if (m != null && phase == 0) {
            var mx = (m.x - hero.x) * sc; var my = (m.z - hero.z) * sc
            val lim = s / 2f - 8f * u
            val k = max(abs(mx), abs(my))
            if (k > lim) { mx *= lim / k; my *= lim / k }
            shape.setColor(1f, 0.85f, 0.1f, 1f); shape.circle(cx + mx, cy + my, 6f * u, 16)
        }
        arrow(cx, cy, hero.yaw, 8f * u)
        shape.end()
        Gdx.gl.glDisable(GL20.GL_SCISSOR_TEST)
    }

    private fun arrow(px: Float, py: Float, yawDeg: Float, size: Float) {
        val yr = yawDeg * MathUtils.degreesToRadians
        val fx = sin(yr); val fz = cos(yr)
        shape.setColor(0.2f, 1f, 0.4f, 1f)
        shape.triangle(
            px + fx * size, py + fz * size,
            px - fx * size * 0.6f + fz * size * 0.6f, py - fz * size * 0.6f - fx * size * 0.6f,
            px - fx * size * 0.6f - fz * size * 0.6f, py - fz * size * 0.6f + fx * size * 0.6f
        )
    }

    private fun drawFullMap() {
        val size = H * 0.86f
        val x0 = (W - size) / 2f; val y0 = (H - size) / 2f
        val sc = size / 440f
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0f, 0f, 0f, 0.75f); shape.rect(0f, 0f, W, H)
        shape.setColor(0.35f, 0.33f, 0.24f, 1f); shape.rect(x0, y0, size, size)
        shape.setColor(0.17f, 0.17f, 0.19f, 1f)
        for (r in world.roads) {
            shape.rect(x0 + (r + 220f - 6f) * sc, y0, 12f * sc, size)
            shape.rect(x0, y0 + (r + 220f - 6f) * sc, size, 12f * sc)
        }
        for (b in world.mapRects) {
            shape.setColor(b.c.r * 0.85f, b.c.g * 0.85f, b.c.b * 0.85f, 1f)
            shape.rect(x0 + (b.x0 + 220f) * sc, y0 + (b.z0 + 220f) * sc, (b.x1 - b.x0) * sc, (b.z1 - b.z0) * sc)
        }
        for ((i, m) in missions.withIndex()) {
            if (i < mIdx) shape.setColor(0.4f, 0.4f, 0.4f, 1f)
            else if (i == mIdx) shape.setColor(1f, 0.85f, 0.1f, 1f)
            else shape.setColor(0.9f, 0.5f, 0.1f, 1f)
            shape.circle(x0 + (m.x + 220f) * sc, y0 + (m.z + 220f) * sc, 7f * u, 16)
        }
        arrow(x0 + (hero.x + 220f) * sc, y0 + (hero.z + 220f) * sc, hero.yaw, 11f * u)
        shape.end()
        for ((i, m) in missions.withIndex()) {
            text("${i + 1}", x0 + (m.x + 220f) * sc, y0 + (m.z + 220f) * sc, 1f, Color.BLACK)
        }
        text("MAP  -  tap karke band karo", W / 2f, y0 + size + 4f * u, 1.1f)
        flushTexts()
    }

    // settings panel layout (shared by draw + click)
    private fun sPanel() = floatArrayOf(W / 2f - 310f * u, H / 2f - 190f * u, 620f * u, 380f * u)
    private fun qBtn(i: Int): FloatArray {
        val p = sPanel()
        return floatArrayOf(p[0] + 30f * u + i * 190f * u, p[1] + p[3] - 190f * u, 170f * u, 64f * u)
    }
    private fun closeBtn(): FloatArray {
        val p = sPanel()
        return floatArrayOf(p[0] + p[2] / 2f - 100f * u, p[1] + 30f * u, 200f * u, 60f * u)
    }
    private fun inRect(x: Float, y: Float, r: FloatArray) = x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3]

    private fun settingsClick(x: Float, y: Float) {
        for ((i, q) in Quality.values().withIndex()) if (inRect(x, y, qBtn(i))) { applyQuality(q); return }
        if (inRect(x, y, closeBtn())) settingsOpen = false
    }

    private fun drawSettings() {
        val p = sPanel()
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.setColor(0f, 0f, 0f, 0.55f); shape.rect(0f, 0f, W, H)
        shape.setColor(0.1f, 0.13f, 0.2f, 0.97f); shape.rect(p[0], p[1], p[2], p[3])
        for ((i, q) in Quality.values().withIndex()) {
            val b = qBtn(i)
            if (q == quality) shape.setColor(1f, 0.6f, 0.15f, 1f) else shape.setColor(0.25f, 0.3f, 0.4f, 1f)
            shape.rect(b[0], b[1], b[2], b[3])
        }
        val cb = closeBtn()
        shape.setColor(0.2f, 0.55f, 0.3f, 1f); shape.rect(cb[0], cb[1], cb[2], cb[3])
        shape.end()
        text("SETTINGS", p[0] + p[2] / 2f, p[1] + p[3] - 40f * u, 1.8f)
        text("Graphics quality", p[0] + p[2] / 2f, p[1] + p[3] - 110f * u, 1.2f, Color.LIGHT_GRAY)
        for ((i, q) in Quality.values().withIndex()) {
            val b = qBtn(i)
            text(q.label, b[0] + b[2] / 2f, b[1] + b[3] / 2f, 1.2f)
        }
        text(if (quality.shadows) "Shadows: ON   Draw distance: ${quality.drawDist.toInt()}m" else "Shadows: OFF   Draw distance: ${quality.drawDist.toInt()}m",
            p[0] + p[2] / 2f, p[1] + 140f * u, 1f, Color.LIGHT_GRAY)
        text("CLOSE", cb[0] + cb[2] / 2f, cb[1] + cb[3] / 2f, 1.2f)
        flushTexts()
    }

    override fun resize(width: Int, height: Int) {
        W = width.toFloat(); H = height.toFloat(); u = H / 720f
        if (this::cam.isInitialized) { cam.viewportWidth = W; cam.viewportHeight = H; cam.update() }
        if (this::uiCam.isInitialized) { uiCam.setToOrtho(false, W, H) }
    }

    override fun dispose() {
        modelBatch.dispose(); shadowBatch.dispose(); shadowLight.dispose()
        shape.dispose(); sb.dispose(); font.dispose()
        logo?.dispose()
        Gfx.dispose()
    }
}
