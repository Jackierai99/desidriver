package com.desidrive.game

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3

enum class Beh { WALK, JOG, STAND, PHONE }

class NpcType(
    val name: String, shirtHex: String, pantsHex: String, skinHex: String, hatHex: String?,
    val beh: Beh, val scale: Float = 1f, val speed: Float = 1.4f
) {
    val shirt: Color = Color.valueOf(shirtHex)
    val pants: Color = Color.valueOf(pantsHex)
    val skin: Color = Color.valueOf(skinHex)
    val hat: Color? = if (hatHex != null) Color.valueOf(hatHex) else null
}

private const val SK1 = "8d5524"
private const val SK2 = "c68642"
private const val SK3 = "e0ac69"

/** 25 Indian NPC types. */
val NPC_TYPES: List<NpcType> = listOf(
    NpcType("Chaiwala", "e8e0c8", "d9d2b5", SK2, null, Beh.STAND),
    NpcType("Phone pe baat karta bhai", "2e86de", "2c3e50", SK2, null, Beh.PHONE),
    NpcType("Newspaper uncle", "f5f5f5", "7f8c8d", SK2, "f0e6c8", Beh.STAND),
    NpcType("Sabziwala", "27ae60", "6b4f3a", SK1, "ecf0f1", Beh.STAND),
    NpcType("Auto driver", "8d8d3a", "8d8d3a", SK2, null, Beh.STAND),
    NpcType("Traffic police", "c8b27a", "c8b27a", SK2, "3b3b3b", Beh.STAND),
    NpcType("College student", "e74c3c", "34495e", SK3, null, Beh.WALK),
    NpcType("School bachha", "ffffff", "1f3a93", SK2, null, Beh.WALK, 0.65f),
    NpcType("Office babu", "bdc3c7", "2c3e50", SK2, null, Beh.WALK),
    NpcType("Aunty (saree)", "e84393", "e84393", SK2, "8e44ad", Beh.WALK),
    NpcType("Sadhu baba", "f39c12", "f39c12", SK1, "d35400", Beh.STAND),
    NpcType("Pandit ji", "ffffff", "fdf2e9", SK3, "f1c40f", Beh.WALK),
    NpcType("Dukandaar", "16a085", "2c3e50", SK2, null, Beh.STAND),
    NpcType("Jogger", "f1c40f", "2d3436", SK3, null, Beh.JOG),
    NpcType("Cricketer bachha", "3498db", "ecf0f1", SK2, "e74c3c", Beh.WALK, 0.8f),
    NpcType("Delivery boy", "e67e22", "2d3436", SK2, "e67e22", Beh.JOG, 1f, 1.8f),
    NpcType("Nai (barber)", "dfe6e9", "636e72", SK1, null, Beh.STAND),
    NpcType("Sardarji", "2980b9", "ecf0f1", SK3, "e67e22", Beh.WALK),
    NpcType("Dhaba cook", "ecf0f1", "2d3436", SK1, "ecf0f1", Beh.STAND),
    NpcType("Selfie wali ladki", "fd79a8", "3d3d8f", SK3, null, Beh.PHONE),
    NpcType("Dadaji", "ffffff", "ffffff", SK2, "b2bec3", Beh.WALK, 0.95f, 0.9f),
    NpcType("Mazdoor", "b33939", "7f8fa6", SK1, "f9ca24", Beh.WALK),
    NpcType("Kisan", "f5f6fa", "dcdde1", SK1, "f5cd79", Beh.WALK),
    NpcType("Ice-cream wala", "ff7979", "f5f6fa", SK2, "f5f6fa", Beh.STAND),
    NpcType("Bike wala yuvak", "2d3436", "2980b9", SK2, null, Beh.WALK)
)

class Human(val type: NpcType) {
    var x = 0f; var z = 0f; var yaw = 0f
    var anim = 0f; var moving = false
    var hp = 100f; var alive = true; var isBoss = false
    // walker path
    var axisX = false; var fixed = 0f; var lo = 0f; var hi = 0f; var dir = 1f; var t = 0f

    private val phone = type.beh == Beh.PHONE
    private val legL = Gfx.box(type.pants)
    private val legR = Gfx.box(type.pants)
    private val armL = Gfx.box(type.shirt)
    private val armR = Gfx.box(type.shirt)
    private val torso = Gfx.box(type.shirt)
    private val head = Gfx.sphere(type.skin)
    private val hatI: ModelInstance? = type.hat?.let { Gfx.box(it) }
    private val phoneI: ModelInstance? = if (phone) Gfx.box(Color.BLACK) else null
    val parts: List<ModelInstance> = listOfNotNull(legL, legR, armL, armR, torso, head, hatI, phoneI)

    private fun limb(i: ModelInstance, lx: Float, hipY: Float, swing: Float, len: Float, w: Float, d: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, hipY, 0f).rotate(Vector3.X, swing).translate(0f, -len / 2f, 0f).scale(w, len, d)
    }

    private fun part(i: ModelInstance, lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, ly, lz).scale(sx, sy, sz)
    }

    fun layout() {
        val sw = if (moving) MathUtils.sin(anim) * 38f else 0f
        limb(legL, -0.11f, 0.85f, sw, 0.85f, 0.18f, 0.2f)
        limb(legR, 0.11f, 0.85f, -sw, 0.85f, 0.18f, 0.2f)
        limb(armL, -0.3f, 1.48f, -sw * 0.8f, 0.6f, 0.14f, 0.16f)
        if (phone) limb(armR, 0.3f, 1.48f, -150f, 0.4f, 0.14f, 0.16f)
        else limb(armR, 0.3f, 1.48f, sw * 0.8f, 0.6f, 0.14f, 0.16f)
        part(torso, 0f, 1.2f, 0f, 0.46f, 0.62f, 0.26f)
        part(head, 0f, 1.64f, 0f, 0.27f, 0.3f, 0.27f)
        hatI?.let { part(it, 0f, 1.82f, 0f, 0.34f, 0.16f, 0.34f) }
        phoneI?.let { part(it, 0.3f, 1.84f, 0.2f, 0.07f, 0.14f, 0.03f) }
    }
}

class CarSpec(
    val name: String, val body: Color, val cabin: Color,
    val len: Float, val wid: Float, val bodyH: Float, val cabinH: Float, val clearance: Float,
    val maxSpeed: Float, val accel: Float, val brake: Float, val wheelBase: Float
)

object CarSpecs {
    val SUV = CarSpec("Desi SUV", Color.valueOf("f2f2f2"), Color.valueOf("2b2b2b"), 4.6f, 1.9f, 1.0f, 0.8f, 0.45f, 30f, 9f, 20f, 2.8f)
    val SUPER = CarSpec("Super GT", Color.valueOf("d63031"), Color.valueOf("1e1e1e"), 4.6f, 2.0f, 0.7f, 0.55f, 0.25f, 62f, 16f, 30f, 2.7f)
    val SEDAN = CarSpec("Euro Sedan", Color.valueOf("1e3a8a"), Color.valueOf("111827"), 4.8f, 1.85f, 0.85f, 0.7f, 0.3f, 42f, 11f, 24f, 2.9f)
    val AUTO = CarSpec("Auto Rickshaw", Color.valueOf("f9ca24"), Color.valueOf("27ae60"), 2.8f, 1.4f, 0.8f, 0.9f, 0.35f, 15f, 5f, 12f, 1.8f)
}

class Car(val spec: CarSpec, var x: Float, var z: Float, var yaw: Float, tint: Color? = null) {
    var speed = 0f
    private val body = Gfx.box(tint ?: spec.body)
    private val cabin = Gfx.box(spec.cabin)
    private val wheels = List(4) { Gfx.cyl(Color.valueOf("151515")) }
    private val lampF = List(2) { Gfx.box(Color.valueOf("fff4b0")) }
    private val lampR = List(2) { Gfx.box(Color.valueOf("c0392b")) }
    val parts: List<ModelInstance> = listOf(body, cabin) + wheels + lampF + lampR

    fun layout() {
        val s = spec
        Gfx.put(body, x, 0f, z, yaw, 0f, s.clearance + s.bodyH / 2f, 0f, s.wid, s.bodyH, s.len)
        Gfx.put(cabin, x, 0f, z, yaw, 0f, s.clearance + s.bodyH + s.cabinH / 2f, -s.len * 0.05f, s.wid * 0.86f, s.cabinH, s.len * 0.5f)
        var k = 0
        for (sx in floatArrayOf(-1f, 1f)) for (sz in floatArrayOf(-1f, 1f)) {
            Gfx.put(wheels[k], x, 0f, z, yaw, sx * s.wid * 0.5f, 0.36f, sz * s.wheelBase * 0.5f, 0.72f, 0.28f, 0.72f, 90f)
            k++
        }
        val ly = s.clearance + s.bodyH * 0.55f
        Gfx.put(lampF[0], x, 0f, z, yaw, -s.wid * 0.32f, ly, s.len * 0.5f, 0.3f, 0.18f, 0.06f)
        Gfx.put(lampF[1], x, 0f, z, yaw, s.wid * 0.32f, ly, s.len * 0.5f, 0.3f, 0.18f, 0.06f)
        Gfx.put(lampR[0], x, 0f, z, yaw, -s.wid * 0.32f, ly, -s.len * 0.5f, 0.3f, 0.18f, 0.06f)
        Gfx.put(lampR[1], x, 0f, z, yaw, s.wid * 0.32f, ly, -s.len * 0.5f, 0.3f, 0.18f, 0.06f)
    }
}
