package com.desidrive.game

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.min

enum class Beh { WALK, JOG, STAND, PHONE }

private val TURBANS = setOf("Sardarji", "Pandit ji", "Sadhu baba", "Kisan", "Dadaji", "Sabziwala")

class NpcType(
    val name: String, shirtHex: String, pantsHex: String, skinHex: String, hatHex: String?,
    val beh: Beh, val scale: Float = 1f, val speed: Float = 1.4f
) {
    val shirt: Color = Color.valueOf(shirtHex)
    val pants: Color = Color.valueOf(pantsHex)
    val skin: Color = Color.valueOf(skinHex)
    val hat: Color? = if (hatHex != null) Color.valueOf(hatHex) else null
    val turban: Boolean = name in TURBANS
}

private const val SK1 = "8d5524"
private const val SK2 = "c68642"
private const val SK3 = "e0ac69"

/** 25 Indian NPC types. */
val NPC_TYPES: List<NpcType> = listOf(
    NpcType("Chaiwala", "e8e0c8", "d9d2b5", SK2, null, Beh.STAND),
    NpcType("Phone pe baat karta bhai", "2e86de", "2c3e50", SK2, null, Beh.PHONE),
    NpcType("Newspaper uncle", "f5f5f5", "7f8c8d", SK2, "f0e6c8", Beh.STAND),
    NpcType("Sabziwala", "27ae60", "6b4f3a", SK1, "ecf0f1", Beh.STAND),
    NpcType("Auto driver", "8d8d3a", "8d8d3a", SK2, null, Beh.STAND),
    NpcType("Traffic police", "c8b27a", "c8b27a", SK2, "3b3b3b", Beh.STAND),
    NpcType("College student", "e74c3c", "34495e", SK3, null, Beh.WALK),
    NpcType("School bachha", "ffffff", "1f3a93", SK2, null, Beh.WALK, 0.65f),
    NpcType("Office babu", "bdc3c7", "2c3e50", SK2, null, Beh.WALK),
    NpcType("Aunty (saree)", "e84393", "e84393", SK2, "8e44ad", Beh.WALK),
    NpcType("Sadhu baba", "f39c12", "f39c12", SK1, "d35400", Beh.STAND),
    NpcType("Pandit ji", "ffffff", "fdf2e9", SK3, "f1c40f", Beh.WALK),
    NpcType("Dukandaar", "16a085", "2c3e50", SK2, null, Beh.STAND),
    NpcType("Jogger", "f1c40f", "2d3436", SK3, null, Beh.JOG),
    NpcType("Cricketer bachha", "3498db", "ecf0f1", SK2, "e74c3c", Beh.WALK, 0.8f),
    NpcType("Delivery boy", "e67e22", "2d3436", SK2, "e67e22", Beh.JOG, 1f, 1.8f),
    NpcType("Nai (barber)", "dfe6e9", "636e72", SK1, null, Beh.STAND),
    NpcType("Sardarji", "2980b9", "ecf0f1", SK3, "e67e22", Beh.WALK),
    NpcType("Dhaba cook", "ecf0f1", "2d3436", SK1, "ecf0f1", Beh.STAND),
    NpcType("Selfie wali ladki", "fd79a8", "3d3d8f", SK3, null, Beh.PHONE),
    NpcType("Dadaji", "ffffff", "ffffff", SK2, "b2bec3", Beh.WALK, 0.95f, 0.9f),
    NpcType("Mazdoor", "b33939", "7f8fa6", SK1, "f9ca24", Beh.WALK),
    NpcType("Kisan", "f5f6fa", "dcdde1", SK1, "f5cd79", Beh.WALK),
    NpcType("Ice-cream wala", "ff7979", "f5f6fa", SK2, "f5f6fa", Beh.STAND),
    NpcType("Bike wala yuvak", "2d3436", "2980b9", SK2, null, Beh.WALK)
)

class Human(val type: NpcType) {
    var x = 0f; var z = 0f; var yaw = 0f
    var anim = 0f; var moving = false
    var hp = 100f; var alive = true; var isBoss = false
    // walker path
    var axisX = false; var fixed = 0f; var lo = 0f; var hi = 0f; var dir = 1f; var t = 0f

    private val phone = type.beh == Beh.PHONE
    private val shoeC = Color.valueOf("1b1b1b")
    private val hairC = Color.valueOf("141414")
    private val legL = Gfx.cyl(type.pants)
    private val legR = Gfx.cyl(type.pants)
    private val shoeL = Gfx.box(shoeC)
    private val shoeR = Gfx.box(shoeC)
    private val armL = Gfx.cyl(type.shirt)
    private val armR = Gfx.cyl(type.shirt)
    private val torso = Gfx.cyl(type.shirt)
    private val head = Gfx.sphere(type.skin)
    private val topI: ModelInstance = run {
        val h = type.hat
        if (h != null) (if (type.turban) Gfx.sphere(h) else Gfx.cyl(h)) else Gfx.sphere(hairC)
    }
    private val phoneI: ModelInstance? = if (phone) Gfx.box(Color.BLACK) else null
    val parts: List<ModelInstance> = listOfNotNull(legL, legR, shoeL, shoeR, armL, armR, torso, head, topI, phoneI)

    private fun limb(i: ModelInstance, lx: Float, hipY: Float, swing: Float, len: Float, w: Float, d: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, hipY, 0f).rotate(Vector3.X, swing).translate(0f, -len / 2f, 0f).scale(w, len, d)
    }

    private fun foot(i: ModelInstance, lx: Float, hipY: Float, swing: Float, len: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, hipY, 0f).rotate(Vector3.X, swing).translate(0f, -len + 0.04f, 0.06f).scale(0.2f, 0.09f, 0.34f)
    }

    private fun part(i: ModelInstance, lx: Float, ly: Float, lz: Float, sx: Float, sy: Float, sz: Float) {
        val s = type.scale
        i.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).scale(s, s, s)
            .translate(lx, ly, lz).scale(sx, sy, sz)
    }

    fun layout() {
        val sw = if (moving) MathUtils.sin(anim) * 38f else 0f
        limb(legL, -0.11f, 0.85f, sw, 0.85f, 0.18f, 0.2f)
        limb(legR, 0.11f, 0.85f, -sw, 0.85f, 0.18f, 0.2f)
        foot(shoeL, -0.11f, 0.85f, sw, 0.85f)
        foot(shoeR, 0.11f, 0.85f, -sw, 0.85f)
        limb(armL, -0.3f, 1.48f, -sw * 0.8f, 0.6f, 0.14f, 0.16f)
        if (phone) limb(armR, 0.3f, 1.48f, -150f, 0.4f, 0.14f, 0.16f)
        else limb(armR, 0.3f, 1.48f, sw * 0.8f, 0.6f, 0.14f, 0.16f)
        part(torso, 0f, 1.2f, 0f, 0.46f, 0.62f, 0.26f)
        part(head, 0f, 1.64f, 0f, 0.27f, 0.30f, 0.27f)
        if (type.hat != null) {
            if (type.turban) part(topI, 0f, 1.76f, 0f, 0.34f, 0.24f, 0.34f)
            else part(topI, 0f, 1.84f, 0f, 0.30f, 0.10f, 0.30f)
        } else part(topI, 0f, 1.70f, -0.012f, 0.285f, 0.27f, 0.29f)
        phoneI?.let { part(it, 0.3f, 1.84f, 0.2f, 0.07f, 0.14f, 0.03f) }
    }
}

class CarSpec(
    val name: String, val body: Color, val cabin: Color,
    val len: Float, val wid: Float, val bodyH: Float, val cabinH: Float, val clearance: Float,
    val maxSpeed: Float, val accel: Float, val brake: Float, val wheelBase: Float,
    val kind: Int = 0, val wheelR: Float = 0.36f
)

object CarSpecs {
    val SUV = CarSpec("Desi SUV", Color.valueOf("f2f2f2"), Color.valueOf("2b2b2b"), 4.6f, 1.9f, 1.0f, 0.8f, 0.45f, 30f, 9f, 20f, 2.8f, 1, 0.42f)
    val SUPER = CarSpec("Super GT", Color.valueOf("d63031"), Color.valueOf("1e1e1e"), 4.6f, 2.0f, 0.7f, 0.55f, 0.25f, 62f, 16f, 30f, 2.7f, 2, 0.34f)
    val SEDAN = CarSpec("Euro Sedan", Color.valueOf("1e3a8a"), Color.valueOf("111827"), 4.8f, 1.85f, 0.85f, 0.7f, 0.3f, 42f, 11f, 24f, 2.9f, 0, 0.36f)
    val AUTO = CarSpec("Auto Rickshaw", Color.valueOf("f9ca24"), Color.valueOf("27ae60"), 2.8f, 1.4f, 0.8f, 0.9f, 0.35f, 15f, 5f, 12f, 1.8f, 3, 0.30f)
}

class Car(val spec: CarSpec, var x: Float, var z: Float, var yaw: Float, tint: Color? = null) {
    var speed = 0f
    var steer = 0f   // radians, + = right

    private val ext: ExtCar? = Gfx.externalCar(spec)
    private val cm: CarModel? = if (ext == null) Gfx.carModel(spec, tint ?: spec.body) else null
    private val body: ModelInstance = ModelInstance(ext?.model ?: cm!!.body)

    // wheel slots: lx, lz, steers(1/0)
    private val wpos: Array<FloatArray> = run {
        val xo = spec.wid * 0.5f - 0.09f
        val hb = spec.wheelBase * 0.5f
        if (spec.kind == 3) arrayOf(floatArrayOf(0f, hb, 1f), floatArrayOf(-xo, -hb, 0f), floatArrayOf(xo, -hb, 0f))
        else arrayOf(floatArrayOf(-xo, hb, 1f), floatArrayOf(xo, hb, 1f), floatArrayOf(-xo, -hb, 0f), floatArrayOf(xo, -hb, 0f))
    }
    private val wheels: List<ModelInstance> =
        if (cm != null) List(wpos.size) { ModelInstance(cm.wheel) } else emptyList()
    val parts: List<ModelInstance> = listOf(body) + wheels

    private var spin = 0f
    private var pitch = 0f
    private var roll = 0f
    private var lastSpeed = 0f

    fun layout() {
        val dt = min(Gdx.graphics.deltaTime, 0.05f)
        val e = ext
        if (e != null) {
            body.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw + e.yaw)
                .scale(e.scale, e.scale, e.scale).translate(-e.cx, -e.minY, -e.cz)
            return
        }
        val acc = if (dt > 0f) ((speed - lastSpeed) / dt).coerceIn(-30f, 30f) else 0f
        lastSpeed = speed
        pitch += ((-acc * 0.06f).coerceIn(-3f, 3f) - pitch) * min(1f, dt * 6f)
        val sf = (abs(speed) / spec.maxSpeed).coerceIn(0f, 1f)
        roll += (-steer * sf * 9f - roll) * min(1f, dt * 6f)
        spin = (spin + speed * dt / spec.wheelR * MathUtils.radiansToDegrees) % 360f

        body.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw)
            .rotate(Vector3.Z, roll).rotate(Vector3.X, pitch)
        for (k in wheels.indices) {
            val wp = wpos[k]
            val w = wheels[k]
            w.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, yaw).translate(wp[0], spec.wheelR, wp[1])
            if (wp[2] > 0f) w.transform.rotate(Vector3.Y, -steer * MathUtils.radiansToDegrees)
            w.transform.rotate(Vector3.X, spin)
        }
    }
}
